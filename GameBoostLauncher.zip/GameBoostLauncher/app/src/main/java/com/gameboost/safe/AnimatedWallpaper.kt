package com.gameboost.safe

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import java.util.Random
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/**
 * Fondo animado ligero. Se pausa cuando no es visible (pantalla apagada o app encima)
 * y limita los cuadros por segundo (15 o 30) para no gastar RAM/CPU/batería.
 */
class AnimatedWallpaper : WallpaperService() {

    override fun onCreateEngine(): Engine = WEngine()

    inner class WEngine : Engine() {
        private val prefs = getSharedPreferences("gbs", MODE_PRIVATE)
        private val handler = Handler(Looper.getMainLooper())
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rnd = Random(42)
        private var visible = false
        private var w = 1
        private var h = 1
        private var t = 0f

        private val nStars = 70
        private val sx = FloatArray(nStars); private val sy = FloatArray(nStars)
        private val sv = FloatArray(nStars); private val sr = FloatArray(nStars)
        private val sp = FloatArray(nStars)

        private val nRain = 45
        private val rx = FloatArray(nRain); private val ry = FloatArray(nRain)
        private val rl = FloatArray(nRain); private val rv = FloatArray(nRain)

        private var blobs: Array<RadialGradient> = emptyArray()
        private var blobR = 1f

        private val runner = object : Runnable {
            override fun run() {
                frame()
                if (visible) {
                    val fps = prefs.getInt("wp_fps", 30).coerceIn(5, 60)
                    handler.postDelayed(this, (1000 / fps).toLong())
                }
            }
        }

        override fun onVisibilityChanged(v: Boolean) {
            visible = v
            handler.removeCallbacks(runner)
            if (v) handler.post(runner)
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            w = max(width, 1); h = max(height, 1)
            blobR = max(w, h) * 0.6f
            val cols = intArrayOf(0x8836E6C3.toInt(), 0x886C4CF1.toInt(), 0x88F14C9A.toInt())
            blobs = Array(3) { RadialGradient(0f, 0f, blobR, cols[it], cols[it] and 0x00FFFFFF, Shader.TileMode.CLAMP) }
            for (i in 0 until nStars) {
                sx[i] = rnd.nextFloat() * w; sy[i] = rnd.nextFloat() * h
                sv[i] = 10f + rnd.nextFloat() * 40f; sr[i] = 1f + rnd.nextFloat() * 2.5f
                sp[i] = rnd.nextFloat() * 6.28f
            }
            for (i in 0 until nRain) {
                rx[i] = rnd.nextFloat() * w; ry[i] = rnd.nextFloat() * h
                rl[i] = 40f + rnd.nextFloat() * 120f; rv[i] = 250f + rnd.nextFloat() * 450f
            }
            frame()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            super.onSurfaceDestroyed(holder)
            visible = false
            handler.removeCallbacks(runner)
        }

        override fun onDestroy() {
            super.onDestroy()
            visible = false
            handler.removeCallbacks(runner)
        }

        private fun frame() {
            val fps = prefs.getInt("wp_fps", 30).coerceIn(5, 60)
            val dt = 1f / fps
            t += dt
            val canvas: Canvas = surfaceHolder.lockCanvas() ?: return
            try {
                canvas.drawColor(0xFF0B0F1A.toInt())
                when (prefs.getInt("wp_style", 0)) {
                    0 -> aurora(canvas)
                    1 -> stars(canvas, dt)
                    else -> rain(canvas, dt)
                }
            } finally {
                surfaceHolder.unlockCanvasAndPost(canvas)
            }
        }

        private fun aurora(c: Canvas) {
            if (blobs.isEmpty()) return
            paint.style = Paint.Style.FILL
            for (i in 0 until 3) {
                val x = w * (0.5f + 0.35f * sin(t * 0.35f + i * 2.1f))
                val y = h * (0.5f + 0.35f * cos(t * 0.27f + i * 1.7f))
                c.save()
                c.translate(x, y)
                paint.shader = blobs[i]
                c.drawCircle(0f, 0f, blobR, paint)
                c.restore()
            }
            paint.shader = null
        }

        private fun stars(c: Canvas, dt: Float) {
            paint.shader = null
            paint.style = Paint.Style.FILL
            for (i in 0 until nStars) {
                sy[i] += sv[i] * dt
                if (sy[i] > h) { sy[i] = 0f; sx[i] = rnd.nextFloat() * w }
                val tw = 0.5f + 0.5f * sin(t * 2f + sp[i])
                paint.color = Color.argb((80 + 175 * tw).toInt(), 255, 255, 255)
                c.drawCircle(sx[i], sy[i], sr[i], paint)
            }
        }

        private fun rain(c: Canvas, dt: Float) {
            paint.shader = null
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 3f
            paint.color = Color.argb(150, 60, 255, 200)
            for (i in 0 until nRain) {
                ry[i] += rv[i] * dt
                if (ry[i] - rl[i] > h) { ry[i] = 0f; rx[i] = rnd.nextFloat() * w }
                c.drawLine(rx[i], ry[i] - rl[i], rx[i], ry[i], paint)
            }
            paint.style = Paint.Style.FILL
        }
    }
}
