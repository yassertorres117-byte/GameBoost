package com.gameboost.safe

import android.app.Activity
import android.app.ActivityManager
import android.app.AlertDialog
import android.app.NotificationManager
import android.app.WallpaperManager
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.GestureDetector
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.text.Normalizer
import kotlin.math.abs
import kotlin.math.max

/**
 * GameBoost Launcher: pantalla de inicio estilo Niagara + Modo Juego seguro + fondos animados.
 * No modifica ningún juego. El modo juego solo pide cerrar procesos en segundo plano de apps
 * instaladas por el usuario que NO estén protegidas. Nunca toca apps del sistema.
 */
class MainActivity : Activity() {

    class AppItem(val label: String, val pkg: String, val icon: Drawable, val system: Boolean) {
        val key: String = Normalizer.normalize(label.trim(), Normalizer.Form.NFD)
            .replace(Regex("\\p{M}"), "").uppercase()
        val initial: Char = key.firstOrNull()?.takeIf { it.isLetter() } ?: '#'
    }

    private lateinit var prefs: SharedPreferences
    private val allApps = mutableListOf<AppItem>()
    private var shown = listOf<AppItem>()
    private val protectedSet = mutableSetOf<String>()
    private val favs = mutableListOf<String>()
    private var gamePkg: String? = null
    private val handler = Handler(Looper.getMainLooper())
    private val freeFire = listOf("com.dts.freefireth", "com.dts.freefiremax")

    private lateinit var homeLayer: View
    private lateinit var drawerLayer: View
    private lateinit var favBox: ViewGroup
    private lateinit var favHint: TextView
    private lateinit var memText: TextView
    private lateinit var gameText: TextView
    private lateinit var statusText: TextView
    private lateinit var dndSwitch: Switch
    private lateinit var search: EditText
    private lateinit var appList: ListView
    private lateinit var adapter: AppAdapter
    private lateinit var gestures: GestureDetector

    // --- widgets ---
    private lateinit var widgetBox: LinearLayout
    private lateinit var awm: AppWidgetManager
    private lateinit var widgetHost: AppWidgetHost
    private val widgetIds = mutableListOf<Int>()
    private var pendingId = -1
    private var pendingInfo: AppWidgetProviderInfo? = null
    private val reqBind = 101
    private val reqConfig = 102

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            loadApps(); filter(); buildFavs(); refreshInfo()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("gbs", MODE_PRIVATE)

        homeLayer = findViewById(R.id.homeLayer)
        drawerLayer = findViewById(R.id.drawerLayer)
        favBox = findViewById(R.id.favBox)
        favHint = findViewById(R.id.favHint)
        widgetBox = findViewById(R.id.widgetBox)
        awm = AppWidgetManager.getInstance(this)
        widgetHost = AppWidgetHost(this, 1024)
        memText = findViewById(R.id.memText)
        gameText = findViewById(R.id.gameText)
        statusText = findViewById(R.id.statusText)
        dndSwitch = findViewById(R.id.dndSwitch)
        search = findViewById(R.id.search)
        appList = findViewById(R.id.appList)

        loadApps()
        loadPrefs()
        shown = allApps.toList()
        adapter = AppAdapter()
        appList.adapter = adapter

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { filter() }
        })
        search.setOnEditorActionListener { _, _, _ ->
            shown.firstOrNull()?.let { launch(it.pkg) }
            true
        }
        findViewById<AlphaBar>(R.id.alphaBar).onLetter = { scrollToLetter(it) }

        findViewById<Button>(R.id.btnPlay).setOnClickListener { optimize(true) }
        findViewById<Button>(R.id.btnClean).setOnClickListener { optimize(false) }
        findViewById<Button>(R.id.btnEnd).setOnClickListener { endSession() }
        findViewById<Button>(R.id.btnApps).setOnClickListener { openDrawer() }
        findViewById<Button>(R.id.btnWall).setOnClickListener { chooseWallpaper() }
        findViewById<Button>(R.id.btnMore).setOnClickListener { showMoreMenu() }

        gestures = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 != null && homeLayer.visibility == View.VISIBLE &&
                    e1.y - e2.y > 200 && abs(vy) > 400 && abs(e1.x - e2.x) < 300
                ) {
                    openDrawer(); return true
                }
                return false
            }
        })

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addDataScheme("package")
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(pkgReceiver, f, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(pkgReceiver, f)

        buildFavs()
        loadWidgets()
        refreshInfo()
        handleBoost(intent)
    }

    override fun onStart() {
        super.onStart()
        try { widgetHost.startListening() } catch (_: Exception) {}
    }

    override fun onStop() {
        super.onStop()
        try { widgetHost.stopListening() } catch (_: Exception) {}
    }

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(pkgReceiver) } catch (_: Exception) {}
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        // Al pulsar el botón Inicio volvemos a la pantalla principal
        if (intent?.action == Intent.ACTION_MAIN) showHome()
        handleBoost(intent)
    }

    override fun onResume() {
        super.onResume()
        refreshInfo()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (drawerLayer.visibility == View.VISIBLE) showHome()
        // En la pantalla de inicio de un launcher, "atrás" no hace nada
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        gestures.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    // ---------- Datos ----------
    @Suppress("DEPRECATION")
    private fun loadApps() {
        allApps.clear()
        val pm = packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = if (Build.VERSION.SDK_INT >= 33)
            pm.queryIntentActivities(main, PackageManager.ResolveInfoFlags.of(0))
        else pm.queryIntentActivities(main, 0)
        val seen = HashSet<String>()
        for (ri in list) {
            val ai = ri.activityInfo.applicationInfo
            val pkg = ai.packageName
            if (pkg == packageName || !seen.add(pkg)) continue
            val system = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            allApps.add(AppItem(ri.loadLabel(pm).toString(), pkg, ri.loadIcon(pm), system))
        }
        allApps.sortBy { it.key }
    }

    private fun loadPrefs() {
        protectedSet.clear(); favs.clear()
        if (!prefs.getBoolean("init", false)) {
            allApps.filter { it.pkg in freeFire }.forEach { protectedSet.add(it.pkg); favs.add(it.pkg) }
            gamePkg = allApps.firstOrNull { it.pkg in freeFire }?.pkg
            savePrefs()
        } else {
            protectedSet.addAll(prefs.getStringSet("protected", emptySet()) ?: emptySet())
            prefs.getString("favs", "")?.split("|")?.filter { it.isNotEmpty() }?.let { favs.addAll(it) }
            gamePkg = prefs.getString("game", null)
        }
    }

    private fun savePrefs() {
        prefs.edit()
            .putStringSet("protected", HashSet(protectedSet))
            .putString("favs", favs.joinToString("|"))
            .putString("game", gamePkg)
            .putBoolean("init", true)
            .apply()
    }

    // ---------- Pantallas ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun showHome() {
        drawerLayer.visibility = View.GONE
        homeLayer.visibility = View.VISIBLE
        search.setText("")
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(search.windowToken, 0)
        refreshInfo()
    }

    private fun openDrawer() {
        homeLayer.visibility = View.GONE
        drawerLayer.visibility = View.VISIBLE
        filter()
    }

    private fun filter() {
        val q = search.text.toString().trim().lowercase()
        shown = if (q.isEmpty()) allApps.toList() else allApps.filter { it.label.lowercase().contains(q) }
        adapter.notifyDataSetChanged()
    }

    private fun scrollToLetter(ch: Char) {
        val idx = if (ch == '#') 0 else shown.indexOfFirst { it.initial >= ch && it.initial != '#' }
        if (idx >= 0) appList.setSelection(idx)
    }

    private fun launch(pkg: String) {
        val intent = packageManager.getLaunchIntentForPackage(pkg)
        if (intent != null) {
            startActivity(intent)
            showHome()
        }
    }

    private fun buildFavs() {
        favBox.removeAllViews()
        val items = favs.mapNotNull { p -> allApps.firstOrNull { it.pkg == p } }
        if (items.isEmpty()) {
            favBox.addView(favHint)
            return
        }
        for (item in items) {
            val tv = TextView(this).apply {
                text = item.label
                textSize = 26f
                setTextColor(0xFFFFFFFF.toInt())
                setShadowLayer(6f, 0f, 2f, 0xAA000000.toInt())
                setPadding(0, dp(10), 0, dp(10))
                setOnClickListener { launch(item.pkg) }
                setOnLongClickListener { showMenu(item); true }
            }
            favBox.addView(tv)
        }
    }

    // ---------- Menú de app ----------
    private fun showMenu(item: AppItem) {
        val isFav = item.pkg in favs
        val isProt = item.pkg in protectedSet
        val options = arrayOf(
            if (isFav) "Quitar de favoritos" else "⭐ Añadir a favoritos",
            if (isProt) "Quitar protección (modo juego)" else "🛡 Proteger (modo juego)",
            "🎮 Elegir como mi juego",
            "ℹ️ Info de la app"
        )
        AlertDialog.Builder(this).setTitle(item.label).setItems(options) { _, which ->
            when (which) {
                0 -> if (isFav) favs.remove(item.pkg) else favs.add(item.pkg)
                1 -> if (isProt) protectedSet.remove(item.pkg) else protectedSet.add(item.pkg)
                2 -> { gamePkg = item.pkg; protectedSet.add(item.pkg) }
                3 -> openSettings(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, "package:${item.pkg}")
            }
            savePrefs(); buildFavs(); adapter.notifyDataSetChanged(); refreshInfo()
        }.show()
    }

    private fun showMoreMenu() {
        val options = arrayOf(
            "➕ Añadir widget",
            "🗑 Quitar widget",
            "Hacer este launcher mi inicio",
            "Ajustes de batería",
            "Animaciones (Opciones de desarrollador)"
        )
        AlertDialog.Builder(this).setTitle("Más").setItems(options) { _, which ->
            when (which) {
                0 -> showWidgetPicker()
                1 -> showRemoveWidget()
                2 -> openSettings(Settings.ACTION_HOME_SETTINGS)
                3 -> openSettings(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                4 -> {
                    Toast.makeText(this, "Baja las 3 escalas de animación a 0.5x", Toast.LENGTH_LONG).show()
                    openSettings(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)
                }
            }
        }.show()
    }

    // ---------- Widgets ----------
    private fun handleBoost(i: Intent?) {
        if (i != null && i.getBooleanExtra("boost", false)) {
            i.removeExtra("boost")
            showHome()
            optimize(true)
        }
    }

    private fun loadWidgets() {
        widgetIds.clear()
        prefs.getString("widgets", "")?.split("|")?.mapNotNull { it.toIntOrNull() }?.let { widgetIds.addAll(it) }
        widgetBox.removeAllViews()
        val iter = widgetIds.iterator()
        var changed = false
        while (iter.hasNext()) {
            val id = iter.next()
            val info = awm.getAppWidgetInfo(id)
            if (info == null) { iter.remove(); changed = true; continue }
            try {
                val view: AppWidgetHostView = widgetHost.createView(this, id, info)
                view.setAppWidget(id, info)
                val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, max(info.minHeight, dp(72)))
                lp.topMargin = dp(8)
                widgetBox.addView(view, lp)
            } catch (e: Exception) {
                iter.remove(); changed = true
            }
        }
        if (changed) saveWidgets()
    }

    private fun saveWidgets() {
        prefs.edit().putString("widgets", widgetIds.joinToString("|")).apply()
    }

    private fun showWidgetPicker() {
        val providers = awm.installedProviders.sortedBy { it.loadLabel(packageManager).toString().lowercase() }
        if (providers.isEmpty()) {
            Toast.makeText(this, "Tu teléfono no tiene widgets disponibles", Toast.LENGTH_LONG).show()
            return
        }
        val names = providers.map { it.loadLabel(packageManager).toString() }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Elige un widget").setItems(names) { _, which ->
            startAddWidget(providers[which])
        }.show()
    }

    private fun startAddWidget(info: AppWidgetProviderInfo) {
        val id = widgetHost.allocateAppWidgetId()
        pendingId = id
        pendingInfo = info
        if (awm.bindAppWidgetIdIfAllowed(id, info.provider)) {
            afterBind()
        } else {
            // El sistema pide tu permiso para que este launcher use el widget
            val i = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider)
            try {
                @Suppress("DEPRECATION")
                startActivityForResult(i, reqBind)
            } catch (e: Exception) {
                cancelPending()
                Toast.makeText(this, "No se pudo añadir este widget", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun afterBind() {
        val info = pendingInfo
        if (info?.configure != null) {
            try {
                widgetHost.startAppWidgetConfigureActivityForResult(this, pendingId, 0, reqConfig, null)
            } catch (e: Exception) {
                cancelPending()
                Toast.makeText(this, "No se pudo configurar este widget", Toast.LENGTH_LONG).show()
            }
        } else {
            finishAdd()
        }
    }

    private fun finishAdd() {
        if (pendingId != -1) {
            widgetIds.add(pendingId)
            saveWidgets()
            pendingId = -1
            loadWidgets()
        }
    }

    private fun cancelPending() {
        if (pendingId != -1) widgetHost.deleteAppWidgetId(pendingId)
        pendingId = -1
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            reqBind -> if (resultCode == RESULT_OK) afterBind() else cancelPending()
            reqConfig -> if (resultCode == RESULT_OK) finishAdd() else cancelPending()
        }
    }

    private fun showRemoveWidget() {
        if (widgetIds.isEmpty()) {
            Toast.makeText(this, "No tienes widgets añadidos", Toast.LENGTH_SHORT).show()
            return
        }
        val ids = widgetIds.toList()
        val names = ids.map { awm.getAppWidgetInfo(it)?.loadLabel(packageManager)?.toString() ?: "Widget $it" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Quitar widget").setItems(names) { _, which ->
            val id = ids[which]
            widgetHost.deleteAppWidgetId(id)
            widgetIds.remove(id)
            saveWidgets()
            loadWidgets()
        }.show()
    }

    // ---------- Fondos animados ----------
    private fun chooseWallpaper() {
        val styles = arrayOf("🌌 Aurora", "✨ Estrellas", "🌧 Lluvia neón")
        AlertDialog.Builder(this).setTitle("Fondo animado").setItems(styles) { _, s ->
            prefs.edit().putInt("wp_style", s).apply()
            val fps = arrayOf("30 FPS (fluido)", "15 FPS (ahorra batería y RAM)")
            AlertDialog.Builder(this).setTitle("Fluidez").setItems(fps) { _, f ->
                prefs.edit().putInt("wp_fps", if (f == 0) 30 else 15).apply()
                applyWallpaper()
            }.show()
        }.show()
    }

    private fun applyWallpaper() {
        val wm = WallpaperManager.getInstance(this)
        if (wm.wallpaperInfo?.packageName == packageName) {
            Toast.makeText(this, "Fondo actualizado", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            startActivity(
                Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).putExtra(
                    WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                    ComponentName(this, AnimatedWallpaper::class.java)
                )
            )
        } catch (e: Exception) {
            try { startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER)) }
            catch (e2: Exception) { Toast.makeText(this, "Tu teléfono no permite fondos animados", Toast.LENGTH_LONG).show() }
        }
    }

    // ---------- Modo juego ----------
    private fun memInfo(): ActivityManager.MemoryInfo {
        val mi = ActivityManager.MemoryInfo()
        (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        return mi
    }

    private fun mb(bytes: Long) = bytes / 1048576

    private fun refreshInfo() {
        val mi = memInfo()
        memText.text = "RAM libre: ${mb(mi.availMem)} MB de ${mb(mi.totalMem)} MB"
        val name = allApps.firstOrNull { it.pkg == gamePkg }?.label ?: "(mantén presionada una app y elige 🎮)"
        gameText.text = "🎮 Juego: $name"
    }

    private fun safeSkipSet(): Set<String> {
        val skip = HashSet<String>(protectedSet)
        skip.add(packageName)
        gamePkg?.let { skip.add(it) }
        val home = packageManager.resolveActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME),
            PackageManager.MATCH_DEFAULT_ONLY
        )?.activityInfo?.packageName
        home?.let { skip.add(it) }
        Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
            ?.substringBefore('/')?.let { skip.add(it) }
        return skip
    }

    private fun optimize(launchAfter: Boolean) {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val before = mb(memInfo().availMem)
        val skip = safeSkipSet()
        var count = 0
        for (a in allApps) {
            if (a.system || a.pkg in skip) continue   // jamás apps del sistema
            am.killBackgroundProcesses(a.pkg)
            count++
        }
        if (dndSwitch.isChecked) enableDnd()
        statusText.text = "Limpiando…"
        handler.postDelayed({
            val after = mb(memInfo().availMem)
            statusText.text = "Listo: se pidió cerrar $count apps. RAM libre: $before → $after MB " +
                "(Android puede reiniciar algunas solas)."
            refreshInfo()
            if (launchAfter) {
                if (gamePkg == null) Toast.makeText(this, "Elige tu juego: mantén presionada una app", Toast.LENGTH_LONG).show()
                else launch(gamePkg!!)
            }
        }, 1500)
    }

    private fun enableDnd() {
        val nm = getSystemService(NotificationManager::class.java)
        if (!nm.isNotificationPolicyAccessGranted) {
            Toast.makeText(this, "Autoriza GameBoost Launcher para usar No molestar", Toast.LENGTH_LONG).show()
            openSettings(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
            return
        }
        if (!prefs.contains("prev_filter")) prefs.edit().putInt("prev_filter", nm.currentInterruptionFilter).apply()
        nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
    }

    private fun endSession() {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.isNotificationPolicyAccessGranted && prefs.contains("prev_filter")) {
            val prev = prefs.getInt("prev_filter", 1)
            if (prev in 1..4) nm.setInterruptionFilter(prev)
        }
        prefs.edit().remove("prev_filter").apply()
        statusText.text = "Sesión terminada: No molestar restaurado."
    }

    private fun openSettings(action: String, uri: String? = null) {
        try {
            val i = Intent(action)
            if (uri != null) i.data = Uri.parse(uri)
            startActivity(i)
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    // ---------- Lista del cajón ----------
    inner class AppAdapter : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(position: Int) = shown[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val v = convertView ?: LayoutInflater.from(this@MainActivity).inflate(R.layout.item_app, parent, false)
            val item = shown[position]
            v.findViewById<ImageView>(R.id.icon).setImageDrawable(item.icon)
            v.findViewById<TextView>(R.id.name).text = item.label
            v.findViewById<TextView>(R.id.tag).text = buildString {
                if (item.pkg in favs) append("⭐ ")
                if (item.pkg == gamePkg) append("🎮 ")
                if (item.pkg in protectedSet) append("🛡")
            }
            v.setOnClickListener { launch(item.pkg) }
            v.setOnLongClickListener { showMenu(item); true }
            return v
        }
    }
}
