package com.gameboost.safe

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

/** Barra lateral A-Z (estilo Niagara) para saltar rápido en la lista de apps. */
class AlphaBar @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {
    var onLetter: ((Char) -> Unit)? = null
    private val letters = "#ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
    }

    override fun onDraw(canvas: Canvas) {
        val step = height / letters.length.toFloat()
        paint.textSize = minOf(step * 0.7f, 40f)
        for (i in letters.indices) {
            canvas.drawText(letters[i].toString(), width / 2f, i * step + step * 0.75f, paint)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_DOWN || e.action == MotionEvent.ACTION_MOVE) {
            parent?.requestDisallowInterceptTouchEvent(true)
            val step = height / letters.length.toFloat()
            val i = (e.y / step).toInt().coerceIn(0, letters.length - 1)
            onLetter?.invoke(letters[i])
        }
        return true
    }
}
