package com.yts.cyberhud

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Resources
import android.graphics.drawable.Drawable
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory

class IconPack(
    private val res: Resources,
    private val pkg: String,
    private val map: Map<String, String>
) {
    fun iconFor(component: ComponentName): Drawable? {
        val name = map[component.flattenToString()] ?: return null
        val id = res.getIdentifier(name, "drawable", pkg)
        if (id == 0) return null
        return try {
            res.getDrawable(id, null)
        } catch (e: Exception) {
            null
        }
    }
}

private val ICON_PACK_ACTIONS = listOf(
    "org.adw.launcher.THEMES",
    "com.novalauncher.THEME",
    "com.gau.go.launcherex.theme"
)

/** Devuelve pares (paquete, nombre) de los paquetes de íconos instalados. */
fun findIconPacks(context: Context): List<Pair<String, String>> {
    val pm = context.packageManager
    val found = LinkedHashMap<String, String>()
    for (action in ICON_PACK_ACTIONS) {
        try {
            pm.queryIntentActivities(Intent(action), 0).forEach {
                found[it.activityInfo.packageName] = it.loadLabel(pm).toString()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
    return found.map { it.key to it.value }
}

private fun openAppFilter(res: Resources, pkg: String): XmlPullParser? {
    val id = res.getIdentifier("appfilter", "xml", pkg)
    if (id != 0) return res.getXml(id)
    return try {
        val parser = XmlPullParserFactory.newInstance().newPullParser()
        parser.setInput(res.assets.open("appfilter.xml"), null)
        parser
    } catch (e: Exception) {
        null
    }
}

fun loadIconPack(context: Context, pkg: String): IconPack? = try {
    val res = context.packageManager.getResourcesForApplication(pkg)
    val parser = openAppFilter(res, pkg)
    if (parser == null) {
        null
    } else {
        val map = HashMap<String, String>()
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG && parser.name == "item") {
                val comp = parser.getAttributeValue(null, "component")
                val drawable = parser.getAttributeValue(null, "drawable")
                if (comp != null && drawable != null && comp.startsWith("ComponentInfo{")) {
                    map[comp.removePrefix("ComponentInfo{").removeSuffix("}")] = drawable
                }
            }
            event = parser.next()
        }
        IconPack(res, pkg, map)
    }
} catch (e: Exception) {
    null
}
