package com.yts.cyberhud

import android.annotation.SuppressLint
import android.app.Activity
import android.app.ActivityManager
import android.app.ActivityOptions
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

private const val HOST_ID = 1024

class MainActivity : ComponentActivity() {

    private lateinit var appWidgetManager: AppWidgetManager
    private lateinit var appWidgetHost: AppWidgetHost
    private var homeSignal by mutableStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )

        appWidgetManager = AppWidgetManager.getInstance(this)
        appWidgetHost = AppWidgetHost(this, HOST_ID)

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                val settings = remember { LauncherSettings(this@MainActivity) }
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color.Transparent,
                    contentColor = Color.White
                ) {
                    Box(Modifier.fillMaxSize()) {
                        WallpaperLayer(settings)
                        NexusLauncherScreen(
                            s = settings,
                            appWidgetManager = appWidgetManager,
                            appWidgetHost = appWidgetHost,
                            homeSignal = homeSignal
                        )
                    }
                }
            }
        }
    }

    // Al pulsar el botón Inicio estando ya en el launcher: volver a la página 1 y cerrar menús
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN && intent.hasCategory(Intent.CATEGORY_HOME)) {
            homeSignal++
        }
    }

    override fun onStart() {
        super.onStart()
        try { appWidgetHost.startListening() } catch (e: Exception) { e.printStackTrace() }
    }

    override fun onStop() {
        super.onStop()
        try { appWidgetHost.stopListening() } catch (e: Exception) { e.printStackTrace() }
    }
}

// ---------------- Componentes ----------------

@Composable
fun MenuOption(text: String, onClick: () -> Unit) {
    Text(
        text = text,
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 12.dp),
        fontSize = 15.sp
    )
}

@Composable
fun RadialCommandDial(palette: ThemeColors, onOptionSelected: (String) -> Unit) {
    val options = listOf(
        Pair("Launcher", "LAUNCHER"),
        Pair("Cortina", "NOTIFICATIONS"),
        Pair("Sistema", "SYSTEM"),
        Pair("Temas", "THEMES")
    )
    Box(modifier = Modifier.size(280.dp), contentAlignment = Alignment.Center) {
        Box(
            modifier = Modifier
                .size(90.dp)
                .clip(CircleShape)
                .background(palette.primaryColor)
                .clickable { onOptionSelected("CLOSE") },
            contentAlignment = Alignment.Center
        ) {
            Text(text = "YTS", color = Color.Black, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
        }

        options.forEachIndexed { index, pair ->
            val angle = (2 * Math.PI / options.size) * index
            val radius = 100.0
            val xOffset = (radius * cos(angle)).dp
            val yOffset = (radius * sin(angle)).dp

            Box(
                modifier = Modifier
                    .offset(x = xOffset, y = yOffset)
                    .size(68.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF1E1E2A))
                    .border(2.dp, palette.primaryColor, CircleShape)
                    .clickable { onOptionSelected(pair.second) },
                contentAlignment = Alignment.Center
            ) {
                Text(text = pair.first, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

/** Escala al presionar según el estilo de animación elegido. */
@Composable
fun pressScale(pressed: Boolean, s: LauncherSettings, depth: Float): Float {
    val speed = s.animSpeed.coerceIn(0.25f, 4f)
    val target = if (pressed && s.pressAnim != PressAnim.NONE) depth else 1f
    val spec: AnimationSpec<Float> = when (s.pressAnim) {
        PressAnim.BOUNCE -> spring(dampingRatio = 0.4f, stiffness = Spring.StiffnessMedium * speed)
        else -> tween((160 / speed).toInt())
    }
    val value by animateFloatAsState(targetValue = target, animationSpec = spec, label = "press")
    return value
}

/** Animación de entrada de cada ítem de la lista. */
@Composable
fun Modifier.entrance(s: LauncherSettings): Modifier {
    if (s.entranceAnim == EntranceAnim.NONE) return this
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val speed = s.animSpeed.coerceIn(0.25f, 4f)
    val p by animateFloatAsState(
        targetValue = if (shown) 1f else 0f,
        animationSpec = tween((350 / speed).toInt()),
        label = "entrance"
    )
    val style = s.entranceAnim
    return this.graphicsLayer {
        alpha = p
        when (style) {
            EntranceAnim.SLIDE_UP -> translationY = (1f - p) * 60f
            EntranceAnim.ZOOM -> {
                scaleX = 0.7f + 0.3f * p
                scaleY = 0.7f + 0.3f * p
            }
            else -> {}
        }
    }
}

@Composable
fun AppIcon(app: AppInfo, s: LauncherSettings, sizeScale: Float = 1f) {
    val bitmap = remember(app.packageName, app.icon) { app.icon.toBitmap(128, 128).asImageBitmap() }
    val size = (s.iconSize * sizeScale).dp
    if (s.iconShape == IconShape.ORIGINAL) {
        Image(bitmap = bitmap, contentDescription = null, modifier = Modifier.size(size))
    } else {
        Box(
            modifier = Modifier
                .size(size)
                .clip(s.iconShape.shape)
                .background(Color(0xFF1E1E2A)),
            contentAlignment = Alignment.Center
        ) {
            Image(bitmap = bitmap, contentDescription = null, modifier = Modifier.size(size * 0.78f))
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppRowItem(
    app: AppInfo,
    s: LauncherSettings,
    palette: ThemeColors,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale = pressScale(pressed, s, 0.95f)
    val liveNotification = NexusNotificationListener.activeNotifications[app.packageName]

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .entrance(s)
            .scale(scale)
            .clip(RoundedCornerShape(14.dp))
            .background(if (app.isFavorite) palette.primaryColor.copy(alpha = 0.2f) else palette.containerBg)
            .combinedClickable(
                interactionSource = interaction,
                indication = null,
                onClick = onClick,
                onLongClick = onLongClick
            )
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AppIcon(app, s)
        Spacer(modifier = Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(text = app.label, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            if (liveNotification != null) {
                Text(text = liveNotification, color = palette.primaryColor, fontSize = 12.sp, maxLines = 1, fontWeight = FontWeight.Bold)
            } else {
                Text(text = app.category.title, color = Color.Gray, fontSize = 12.sp)
            }
        }
        IconButton(onClick = { s.toggleFavorite(app.packageName) }) {
            Icon(
                imageVector = if (app.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                contentDescription = null,
                tint = if (app.isFavorite) palette.primaryColor else Color.DarkGray
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppGridItem(
    app: AppInfo,
    s: LauncherSettings,
    palette: ThemeColors,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale = pressScale(pressed, s, 0.90f)

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .entrance(s)
            .scale(scale)
            .clip(RoundedCornerShape(12.dp))
            .background(if (app.isFavorite) palette.primaryColor.copy(alpha = 0.2f) else Color.Transparent)
            .combinedClickable(
                interactionSource = interaction,
                indication = null,
                onClick = onClick,
                onLongClick = onLongClick
            )
            .padding(8.dp)
    ) {
        AppIcon(app, s)
        if (s.showLabels) {
            Spacer(modifier = Modifier.height(6.dp))
            Text(text = app.label, color = Color.White, fontSize = 12.sp, maxLines = 1)
        }
    }
}

@Composable
fun FavoriteItemChip(app: AppInfo, s: LauncherSettings, palette: ThemeColors, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(palette.containerBg)
            .clickable { onClick() }
            .padding(12.dp)
    ) {
        AppIcon(app, s)
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = app.label, color = Color.White, fontSize = 11.sp, maxLines = 1)
    }
}

// ---------------- Encabezados ----------------

@Composable
fun NexusHudHeader(currentTime: String, fullDate: String, batteryLevel: Int, theme: ThemeColors) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(theme.containerBg)
            .padding(18.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(text = currentTime, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text(text = fullDate, color = theme.primaryColor, fontSize = 12.sp, fontWeight = FontWeight.Medium)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(text = "BATTERY", color = Color.Gray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text(text = "$batteryLevel%", color = if (batteryLevel > 20) Color.Green else Color.Red, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun PixelAtAGlanceHeader(currentTime: String, fullDate: String, theme: ThemeColors) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(theme.containerBg)
            .padding(20.dp)
    ) {
        Text(text = "DE UN VISTAZO • YTS SMART", color = theme.primaryColor, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = fullDate, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(text = currentTime, color = Color.LightGray, fontSize = 14.sp)
    }
}

@Composable
fun AioSystemMonitorHeader(currentTime: String, ramMB: Long, storageGB: Long, battery: Int, theme: ThemeColors) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(theme.containerBg)
            .padding(16.dp)
    ) {
        Text(text = "> SYSTEM MONITOR [YTS ENGINE]", color = theme.primaryColor, fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(text = "RAM LIBRE: ${ramMB}MB", color = Color.Cyan, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
            Text(text = "STORAGE: ${storageGB}GB", color = Color.Yellow, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = "BAT: $battery%  |  $currentTime", color = Color.LightGray, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
    }
}

@Composable
fun FocusMinimalHeader(fullDate: String) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp, horizontal = 4.dp)) {
        Text(text = "MODO ENFOQUE / CONCENTRACIÓN", color = Color.Gray, fontSize = 11.sp)
        Text(text = fullDate, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Light)
    }
}

// ---------------- Utilidades del sistema ----------------

fun getCurrentTimeString(): String = SimpleDateFormat("hh:mm:ss a", Locale.getDefault()).format(Date())

fun getFullDateString(): String =
    SimpleDateFormat("EEEE, d 'de' MMMM 'de' yyyy", Locale("es", "ES")).format(Date())
        .replaceFirstChar { it.uppercase() }

fun getBatteryPercentage(context: Context): Int =
    (context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager)
        .getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)

fun getAvailableRAM(context: Context): Long {
    val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val mi = ActivityManager.MemoryInfo()
    am.getMemoryInfo(mi)
    return mi.availMem / (1024 * 1024)
}

fun getAvailableStorageGB(): Long {
    val stat = StatFs(Environment.getDataDirectory().path)
    return (stat.blockSizeLong * stat.availableBlocksLong) / (1024 * 1024 * 1024)
}

@SuppressLint("WrongConstant")
fun openNotificationShade(context: Context) {
    try {
        val sbs = context.getSystemService("statusbar")
        Class.forName("android.app.StatusBarManager").getMethod("expandNotificationsPanel").invoke(sbs)
    } catch (e: Exception) {
        e.printStackTrace()
    }
}

fun openNotificationListenerSettings(context: Context) {
    try {
        context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        e.printStackTrace()
    }
}

fun openSettings(context: Context) {
    try {
        context.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        e.printStackTrace()
    }
}

fun getInstalledApps(context: Context, iconPackName: String): List<AppInfo> {
    val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
    val pm = context.packageManager
    val pack = if (iconPackName.isNotEmpty()) loadIconPack(context, iconPackName) else null
    return pm.queryIntentActivities(intent, 0)
        .filter { it.activityInfo.packageName != context.packageName }
        .map { ri ->
            val comp = ComponentName(ri.activityInfo.packageName, ri.activityInfo.name)
            AppInfo(
                label = ri.loadLabel(pm).toString(),
                packageName = ri.activityInfo.packageName,
                component = comp,
                icon = pack?.iconFor(comp) ?: ri.loadIcon(pm),
                category = detectCategory(ri.activityInfo.packageName, ri.activityInfo.applicationInfo)
            )
        }
        .distinctBy { it.packageName }
        .sortedBy { it.label.lowercase() }
}

@Suppress("DEPRECATION")
fun detectCategory(pkg: String, appInfo: ApplicationInfo): AppCategory {
    val p = pkg.lowercase()
    return when {
        p.contains("game") || p.contains("freefire") || (appInfo.flags and ApplicationInfo.FLAG_IS_GAME) != 0 -> AppCategory.JUEGOS
        p.contains("whatsapp") || p.contains("instagram") || p.contains("facebook") || p.contains("tiktok") -> AppCategory.SOCIAL
        else -> AppCategory.HERRAMIENTAS
    }
}

/** Abre una app con la animación elegida en Ajustes. */
fun launchApp(context: Context, view: View?, pkg: String, anim: OpenAnim) {
    val intent = context.packageManager.getLaunchIntentForPackage(pkg) ?: return
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    val options: ActivityOptions? = try {
        when (anim) {
            OpenAnim.ZOOM ->
                if (view != null) ActivityOptions.makeScaleUpAnimation(view, view.width / 2, view.height / 2, 0, 0) else null
            OpenAnim.FADE ->
                ActivityOptions.makeCustomAnimation(context, android.R.anim.fade_in, android.R.anim.fade_out)
            OpenAnim.SLIDE ->
                ActivityOptions.makeCustomAnimation(context, android.R.anim.slide_in_left, android.R.anim.slide_out_right)
            OpenAnim.NONE ->
                ActivityOptions.makeCustomAnimation(context, 0, 0)
        }
    } catch (e: Exception) {
        null
    }
    try {
        context.startActivity(intent, options?.toBundle())
    } catch (e: Exception) {
        e.printStackTrace()
    }
}
