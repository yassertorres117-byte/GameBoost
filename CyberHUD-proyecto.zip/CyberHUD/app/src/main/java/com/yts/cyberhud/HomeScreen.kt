package com.yts.cyberhud

import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.zIndex
import kotlin.math.abs
import kotlin.math.roundToInt

data class LiveInfo(
    val time: String,
    val date: String,
    val battery: Int,
    val ramMB: Long,
    val storageGB: Long
)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(
    s: LauncherSettings,
    palette: ThemeColors,
    apps: List<AppInfo>,
    live: LiveInfo,
    appWidgetHost: AppWidgetHost,
    appWidgetManager: AppWidgetManager,
    homeSignal: Int,
    editMode: Boolean,
    onEditModeChange: (Boolean) -> Unit,
    onOpenApp: (String) -> Unit,
    onOpenDrawer: () -> Unit,
    onAddWidget: (page: Int, col: Int, row: Int) -> Unit,
    onPerform: (GestureAction) -> Unit,
    onOpenSettings: () -> Unit,
    onOpenNotificationSettings: () -> Unit
) {
    val context = LocalContext.current
    val density = LocalDensity.current
    val accent = palette.primaryColor

    val items = s.homeItems
    val dock = s.dockPackages
    val appMap = remember(apps) { apps.associateBy { it.packageName } }
    val pagerState = rememberPagerState(pageCount = { s.homePages })

    var dragId by remember { mutableStateOf<String?>(null) }
    var dragOff by remember { mutableStateOf(Offset.Zero) }
    var itemMenu by remember { mutableStateOf<HomeItem?>(null) }
    var resizeItem by remember { mutableStateOf<HomeItem?>(null) }
    var addTarget by remember { mutableStateOf<Triple<Int, Int, Int>?>(null) }
    var addStep by remember { mutableStateOf("menu") }
    var openFolder by remember { mutableStateOf<String?>(null) }
    var dockMenuPkg by remember { mutableStateOf<String?>(null) }
    var showThemePicker by remember { mutableStateOf(false) }

    fun toast(msg: String) {
        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
    }

    LaunchedEffect(homeSignal) {
        if (homeSignal > 0) {
            showThemePicker = false
            addTarget = null
            itemMenu = null
            resizeItem = null
            openFolder = null
            dockMenuPkg = null
            pagerState.animateScrollToPage(0)
        }
    }

    val finishDrag: (HomeItem, Float, Float) -> Unit = { item, cw, ch ->
        val off = dragOff
        dragId = null
        dragOff = Offset.Zero
        if (abs(off.x) < 16f && abs(off.y) < 16f) {
            itemMenu = item
        } else {
            val maxCol = (s.homeCols - item.spanC).coerceAtLeast(0)
            val maxRow = (s.homeRows - item.spanR).coerceAtLeast(0)
            val newCol = ((item.col * cw + off.x) / cw).roundToInt().coerceIn(0, maxCol)
            val newRow = ((item.row * ch + off.y) / ch).roundToInt().coerceIn(0, maxRow)
            if (!s.moveHomeItem(item.id, newCol, newRow)) toast("Ese espacio está ocupado")
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onVerticalDrag = { _, dy -> total += dy },
                    onDragEnd = {
                        if (dragId == null) {
                            if (total < -120f) onPerform(s.swipeUpAction)
                            else if (total > 120f) onPerform(s.swipeDownAction)
                        }
                        total = 0f
                    },
                    onDragCancel = { total = 0f }
                )
            }
    ) {
        // ---------- Barra superior ----------
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { showThemePicker = !showThemePicker }) {
                Icon(Icons.Default.Palette, contentDescription = "Tema", tint = accent)
            }
            IconButton(onClick = onOpenSettings) {
                Icon(Icons.Default.Settings, contentDescription = "Personalizar", tint = accent)
            }
            IconButton(onClick = onOpenNotificationSettings) {
                Icon(Icons.Default.Notifications, contentDescription = "Notificaciones", tint = accent)
            }
        }

        AnimatedVisibility(visible = showThemePicker) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xCC14141E))
                    .padding(10.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                NeonTheme.values().forEach { theme ->
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(theme.primaryColor)
                            .border(
                                width = if (s.theme == theme && s.accentHue < 0f) 3.dp else 0.dp,
                                color = Color.White,
                                shape = CircleShape
                            )
                            .clickable {
                                s.theme = theme
                                s.accentHue = -1f
                                showThemePicker = false
                            }
                    )
                }
            }
        }

        // ---------- Encabezado (reloj, batería...) ----------
        if (s.showHeader) {
            Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                when (s.engineMode) {
                    LauncherEngineMode.NEXUS_HUD -> NexusHudHeader(live.time, live.date, live.battery, palette)
                    LauncherEngineMode.PIXEL_AT_A_GLANCE -> PixelAtAGlanceHeader(live.time, live.date, palette)
                    LauncherEngineMode.AIO_HACKER -> AioSystemMonitorHeader(live.time, live.ramMB, live.storageGB, live.battery, palette)
                    LauncherEngineMode.FOCUS_MINIMAL -> FocusMinimalHeader(live.date)
                }
            }
        }

        if (editMode) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(accent.copy(alpha = 0.2f))
                    .padding(start = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Modo edición: toca un elemento para ver opciones o arrástralo",
                    color = Color.White,
                    fontSize = 11.sp,
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = { onEditModeChange(false) }) { Text("Listo", color = accent) }
            }
        }

        // ---------- Páginas ----------
        HorizontalPager(
            state = pagerState,
            userScrollEnabled = dragId == null,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) { page ->
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 8.dp)
            ) {
                val cols = s.homeCols
                val rows = s.homeRows
                val wPx = with(density) { maxWidth.toPx() }
                val hPx = with(density) { maxHeight.toPx() }
                val cw = wPx / cols
                val ch = hPx / rows
                val pageItems = items.filter {
                    it.page == page && it.col + it.spanC <= cols && it.row + it.spanR <= rows
                }

                fun occupied(c: Int, r: Int): Boolean = pageItems.any {
                    c >= it.col && c < it.col + it.spanC && r >= it.row && r < it.row + it.spanR
                }

                // Fondo táctil: mantener presionado = añadir; doble toque = gesto elegido
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(page, cols, rows, items) {
                            detectTapGestures(
                                onLongPress = { pos ->
                                    val c = (pos.x / cw).toInt().coerceIn(0, cols - 1)
                                    val r = (pos.y / ch).toInt().coerceIn(0, rows - 1)
                                    if (!occupied(c, r)) {
                                        addStep = "menu"
                                        addTarget = Triple(page, c, r)
                                    }
                                },
                                onDoubleTap = { pos ->
                                    val c = (pos.x / cw).toInt().coerceIn(0, cols - 1)
                                    val r = (pos.y / ch).toInt().coerceIn(0, rows - 1)
                                    if (!occupied(c, r)) onPerform(s.doubleTapAction)
                                }
                            )
                        }
                )

                if (items.isEmpty() && page == 0) {
                    Text(
                        text = "Mantén presionado un espacio vacío\npara añadir apps y widgets",
                        color = Color.White.copy(alpha = 0.7f),
                        fontSize = 14.sp,
                        modifier = Modifier.align(Alignment.Center),
                        style = TextStyle(shadow = Shadow(Color.Black, blurRadius = 8f))
                    )
                }

                pageItems.forEach { item ->
                    key(item.id) {
                        val isDragging = dragId == item.id
                        val wDp = with(density) { (cw * item.spanC).toDp() }
                        val hDp = with(density) { (ch * item.spanR).toDp() }
                        val wInt = (cw * item.spanC / density.density).roundToInt()
                        val hInt = (ch * item.spanR / density.density).roundToInt()

                        Box(
                            modifier = Modifier
                                .offset {
                                    IntOffset(
                                        (item.col * cw + (if (isDragging) dragOff.x else 0f)).roundToInt(),
                                        (item.row * ch + (if (isDragging) dragOff.y else 0f)).roundToInt()
                                    )
                                }
                                .size(wDp, hDp)
                                .zIndex(if (isDragging) 10f else 0f)
                                .graphicsLayer {
                                    val sc = if (isDragging) 1.1f else 1f
                                    scaleX = sc
                                    scaleY = sc
                                    alpha = if (isDragging) 0.85f else 1f
                                }
                        ) {
                            when (item.type) {
                                "app" -> {
                                    val app = appMap[item.ref]
                                    if (app != null) {
                                        Column(
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .then(
                                                    if (editMode) Modifier.border(1.dp, accent.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                                                    else Modifier
                                                )
                                                .pointerInput(item.id, editMode) {
                                                    detectTapGestures(onTap = {
                                                        if (editMode) itemMenu = item else onOpenApp(item.ref)
                                                    })
                                                }
                                                .pointerInput(item.id, cw, ch) {
                                                    detectDragGesturesAfterLongPress(
                                                        onDragStart = {
                                                            dragId = item.id
                                                            dragOff = Offset.Zero
                                                        },
                                                        onDrag = { change, amount ->
                                                            change.consume()
                                                            dragOff += amount
                                                        },
                                                        onDragEnd = { finishDrag(item, cw, ch) },
                                                        onDragCancel = {
                                                            dragId = null
                                                            dragOff = Offset.Zero
                                                        }
                                                    )
                                                }
                                                .padding(4.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            verticalArrangement = Arrangement.Center
                                        ) {
                                            AppIcon(app, s)
                                            if (s.homeLabels) {
                                                Spacer(modifier = Modifier.height(4.dp))
                                                Text(
                                                    text = app.label,
                                                    color = Color.White,
                                                    fontSize = 11.sp,
                                                    maxLines = 1,
                                                    style = TextStyle(shadow = Shadow(Color.Black, blurRadius = 8f))
                                                )
                                            }
                                        }
                                    }
                                }

                                "folder" -> {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .pointerInput(item.id, editMode) {
                                                detectTapGestures(onTap = {
                                                    if (editMode) itemMenu = item else openFolder = item.ref
                                                })
                                            }
                                            .pointerInput(item.id, cw, ch) {
                                                detectDragGesturesAfterLongPress(
                                                    onDragStart = {
                                                        dragId = item.id
                                                        dragOff = Offset.Zero
                                                    },
                                                    onDrag = { change, amount ->
                                                        change.consume()
                                                        dragOff += amount
                                                    },
                                                    onDragEnd = { finishDrag(item, cw, ch) },
                                                    onDragCancel = {
                                                        dragId = null
                                                        dragOff = Offset.Zero
                                                    }
                                                )
                                            }
                                            .padding(4.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(s.iconSize.dp)
                                                .clip(RoundedCornerShape(percent = 28))
                                                .background(Color(0xCC1E1E2A)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(Icons.Default.Folder, contentDescription = null, tint = accent)
                                        }
                                        if (s.homeLabels) {
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = item.ref,
                                                color = Color.White,
                                                fontSize = 11.sp,
                                                maxLines = 1,
                                                style = TextStyle(shadow = Shadow(Color.Black, blurRadius = 8f))
                                            )
                                        }
                                    }
                                }

                                "widget" -> {
                                    val wid = item.ref.toIntOrNull()
                                    val info = if (wid != null) appWidgetManager.getAppWidgetInfo(wid) else null
                                    if (wid != null && info != null) {
                                        AndroidView(
                                            factory = { ctx -> appWidgetHost.createView(ctx, wid, info) },
                                            update = { v -> v.updateAppWidgetSize(null, wInt, hInt, wInt, hInt) },
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .padding(2.dp)
                                        )
                                        if (editMode) {
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxSize()
                                                    .border(2.dp, accent, RoundedCornerShape(12.dp))
                                                    .background(accent.copy(alpha = 0.12f))
                                                    .pointerInput(item.id) {
                                                        detectTapGestures(onTap = { itemMenu = item })
                                                    }
                                                    .pointerInput(item.id, cw, ch) {
                                                        detectDragGestures(
                                                            onDragStart = {
                                                                dragId = item.id
                                                                dragOff = Offset.Zero
                                                            },
                                                            onDrag = { change, amount ->
                                                                change.consume()
                                                                dragOff += amount
                                                            },
                                                            onDragEnd = { finishDrag(item, cw, ch) },
                                                            onDragCancel = {
                                                                dragId = null
                                                                dragOff = Offset.Zero
                                                            }
                                                        )
                                                    }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // ---------- Indicador de páginas ----------
        if (s.homePages > 1) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                repeat(s.homePages) { i ->
                    val current = i == pagerState.currentPage
                    Box(
                        modifier = Modifier
                            .padding(3.dp)
                            .size(if (current) 8.dp else 6.dp)
                            .clip(CircleShape)
                            .background(if (current) accent else Color.Gray)
                    )
                }
            }
        }

        // ---------- Dock ----------
        if (s.showDock) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color(0x66000000))
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                dock.take(5).forEach { pkg ->
                    val app = appMap[pkg]
                    if (app != null) {
                        Box(
                            modifier = Modifier.combinedClickable(
                                onClick = { onOpenApp(pkg) },
                                onLongClick = { dockMenuPkg = pkg }
                            )
                        ) {
                            AppIcon(app, s)
                        }
                    }
                }
                Box(
                    modifier = Modifier
                        .size(s.iconSize.dp)
                        .clip(CircleShape)
                        .background(accent.copy(alpha = 0.25f))
                        .clickable { onOpenDrawer() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Apps, contentDescription = "Todas las apps", tint = accent)
                }
            }
        }
    }

    // ================= Diálogos =================

    // ---- Añadir a una celda vacía ----
    addTarget?.let { target ->
        val page = target.first
        val col = target.second
        val row = target.third
        when (addStep) {
            "menu" -> AlertDialog(
                onDismissRequest = { addTarget = null },
                title = { Text("Añadir a inicio") },
                confirmButton = {},
                dismissButton = { TextButton(onClick = { addTarget = null }) { Text("Cancelar") } },
                text = {
                    Column {
                        MenuOption("Añadir app") { addStep = "app" }
                        MenuOption("Añadir widget") {
                            addTarget = null
                            onAddWidget(page, col, row)
                        }
                        if (s.folders.isNotEmpty()) {
                            MenuOption("Añadir carpeta") { addStep = "folder" }
                        }
                        if (s.favorites.isNotEmpty()) {
                            MenuOption("Añadir mis favoritas") {
                                var failed = false
                                s.favorites.forEach { pkg ->
                                    if (!s.addHomeItem("app", pkg, page = page)) failed = true
                                }
                                if (failed) toast("Algunas no cupieron")
                                addTarget = null
                            }
                        }
                        MenuOption("Modo edición (mover y cambiar tamaño)") {
                            addTarget = null
                            onEditModeChange(true)
                        }
                        MenuOption("Personalizar launcher") {
                            addTarget = null
                            onOpenSettings()
                        }
                    }
                }
            )

            "app" -> AlertDialog(
                onDismissRequest = { addTarget = null },
                title = { Text("Elegir app") },
                confirmButton = {},
                dismissButton = { TextButton(onClick = { addStep = "menu" }) { Text("Atrás") } },
                text = {
                    LazyColumn(modifier = Modifier.heightIn(max = 380.dp)) {
                        items(apps.filter { !s.hidden.contains(it.packageName) }, key = { it.packageName }) { app ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        if (!s.addHomeItem("app", app.packageName, 1, 1, page, col, row)) {
                                            toast("No hay espacio en el inicio")
                                        }
                                        addTarget = null
                                    }
                                    .padding(vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                AppIcon(app, s, 0.8f)
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(app.label, fontSize = 15.sp)
                            }
                        }
                    }
                }
            )

            "folder" -> AlertDialog(
                onDismissRequest = { addTarget = null },
                title = { Text("Elegir carpeta") },
                confirmButton = {},
                dismissButton = { TextButton(onClick = { addStep = "menu" }) { Text("Atrás") } },
                text = {
                    Column {
                        s.folders.forEach { f ->
                            MenuOption(f.name) {
                                if (!s.addHomeItem("folder", f.name, 1, 1, page, col, row)) {
                                    toast("No hay espacio en el inicio")
                                }
                                addTarget = null
                            }
                        }
                    }
                }
            )
        }
    }

    // ---- Opciones de un elemento ----
    itemMenu?.let { item ->
        val app = if (item.type == "app") appMap[item.ref] else null
        val title = when (item.type) {
            "app" -> app?.label ?: "App"
            "widget" -> "Widget"
            else -> item.ref
        }
        AlertDialog(
            onDismissRequest = { itemMenu = null },
            title = { Text(title) },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { itemMenu = null }) { Text("Cerrar") } },
            text = {
                Column {
                    if (item.type == "widget") {
                        MenuOption("Cambiar tamaño") {
                            resizeItem = item
                            itemMenu = null
                        }
                    }
                    if (item.type == "app" && dock.size < 5 && !dock.contains(item.ref)) {
                        MenuOption("Mover al dock") {
                            if (s.addDock(item.ref)) s.removeHomeItem(item.id)
                            itemMenu = null
                        }
                    }
                    if (s.homePages > 1) {
                        if (item.page > 0) {
                            MenuOption("Mover a la página ${item.page}") {
                                if (!s.moveHomeItemToPage(item.id, item.page - 1)) toast("Sin espacio en esa página")
                                itemMenu = null
                            }
                        }
                        if (item.page < s.homePages - 1) {
                            MenuOption("Mover a la página ${item.page + 2}") {
                                if (!s.moveHomeItemToPage(item.id, item.page + 1)) toast("Sin espacio en esa página")
                                itemMenu = null
                            }
                        }
                    }
                    if (item.type == "app") {
                        MenuOption("Información de la app") {
                            openAppInfo(context, item.ref)
                            itemMenu = null
                        }
                        MenuOption("Desinstalar") {
                            uninstallApp(context, item.ref)
                            itemMenu = null
                        }
                    }
                    MenuOption("Quitar de inicio") {
                        if (item.type == "widget") {
                            item.ref.toIntOrNull()?.let { appWidgetHost.deleteAppWidgetId(it) }
                        }
                        s.removeHomeItem(item.id)
                        itemMenu = null
                    }
                }
            }
        )
    }

    // ---- Cambiar tamaño de widget ----
    resizeItem?.let { item ->
        var newC by remember(item.id) { mutableStateOf(item.spanC) }
        var newR by remember(item.id) { mutableStateOf(item.spanR) }
        AlertDialog(
            onDismissRequest = { resizeItem = null },
            title = { Text("Tamaño del widget") },
            text = {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Ancho", modifier = Modifier.weight(1f))
                        TextButton(onClick = { if (newC > 1) newC-- }) { Text("-") }
                        Text("$newC", fontWeight = FontWeight.Bold)
                        TextButton(onClick = { if (newC < s.homeCols) newC++ }) { Text("+") }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Alto", modifier = Modifier.weight(1f))
                        TextButton(onClick = { if (newR > 1) newR-- }) { Text("-") }
                        Text("$newR", fontWeight = FontWeight.Bold)
                        TextButton(onClick = { if (newR < s.homeRows) newR++ }) { Text("+") }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (!s.resizeHomeItem(item.id, newC, newR)) toast("No cabe en ese espacio")
                    resizeItem = null
                }) { Text("Aplicar") }
            },
            dismissButton = { TextButton(onClick = { resizeItem = null }) { Text("Cancelar") } }
        )
    }

    // ---- Contenido de una carpeta ----
    openFolder?.let { name ->
        val folder = s.folders.firstOrNull { it.name == name }
        AlertDialog(
            onDismissRequest = { openFolder = null },
            title = { Text(name) },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { openFolder = null }) { Text("Cerrar") } },
            text = {
                val folderApps = apps.filter { folder?.packageNames?.contains(it.packageName) == true }
                if (folderApps.isEmpty()) {
                    Text("Carpeta vacía. Añade apps desde el cajón (mantén presionada una app).")
                } else {
                    LazyColumn(modifier = Modifier.heightIn(max = 380.dp)) {
                        items(folderApps, key = { it.packageName }) { app ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        openFolder = null
                                        onOpenApp(app.packageName)
                                    }
                                    .padding(vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                AppIcon(app, s, 0.8f)
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(app.label, fontSize = 15.sp)
                            }
                        }
                    }
                }
            }
        )
    }

    // ---- Opciones de un ícono del dock ----
    dockMenuPkg?.let { pkg ->
        AlertDialog(
            onDismissRequest = { dockMenuPkg = null },
            title = { Text(appMap[pkg]?.label ?: "Dock") },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { dockMenuPkg = null }) { Text("Cerrar") } },
            text = {
                Column {
                    MenuOption("Quitar del dock") {
                        s.removeDock(pkg)
                        dockMenuPkg = null
                    }
                    MenuOption("Información de la app") {
                        openAppInfo(context, pkg)
                        dockMenuPkg = null
                    }
                }
            }
        )
    }
}
