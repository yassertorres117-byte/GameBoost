package com.yts.cyberhud

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(
    s: LauncherSettings,
    palette: ThemeColors,
    apps: List<AppInfo>,
    iconPacks: List<Pair<String, String>>,
    onPickPhoto: () -> Unit,
    onExport: () -> Unit,
    onImport: () -> Unit,
    onReset: () -> Unit,
    onClose: () -> Unit
) {
    val accent = palette.primaryColor
    val ctx = LocalContext.current
    var confirmReset by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFA0C0C12))
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "< Atrás",
                color = accent,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .clickable { onClose() }
                    .padding(end = 16.dp, top = 4.dp, bottom = 4.dp)
            )
            Text("Personalización", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
        ) {
            // ---------------- APARIENCIA ----------------
            SectionTitle("APARIENCIA", accent)
            Label("Tema")
            ChipRow(NeonTheme.values().toList(), s.theme, { it.label }, accent) { s.theme = it }
            SwitchRow("Color personalizado", s.accentHue >= 0f, accent) { on ->
                s.accentHue = if (on) 190f else -1f
            }
            if (s.accentHue >= 0f) {
                SliderRow("Tono del color", s.accentHue, 0f..360f, 0, accent, "${s.accentHue.roundToInt()}°") {
                    s.accentHue = it
                }
            }
            Label("Estilo del encabezado")
            ChipRow(LauncherEngineMode.values().toList(), s.engineMode, { it.label }, accent) { s.engineMode = it }

            // ---------------- ÍCONOS ----------------
            SectionTitle("ÍCONOS", accent)
            Label("Forma")
            ChipRow(IconShape.values().toList(), s.iconShape, { it.label }, accent) { s.iconShape = it }
            SliderRow("Tamaño", s.iconSize, 32f..72f, 0, accent, "${s.iconSize.roundToInt()} dp") { s.iconSize = it }
            SwitchRow("Mostrar nombres (cuadrícula)", s.showLabels, accent) { s.showLabels = it }
            Label("Paquete de íconos")
            val packOptions = listOf("" to "Ninguno") + iconPacks
            ChipRow(
                packOptions,
                packOptions.firstOrNull { it.first == s.iconPack } ?: packOptions[0],
                { it.second },
                accent
            ) { s.iconPack = it.first }
            if (iconPacks.isEmpty()) {
                Hint("No hay paquetes de íconos instalados. Instala uno desde Play Store (compatible con Nova/ADW) y vuelve aquí.")
            }

            // ---------------- FONDO ----------------
            SectionTitle("FONDO DE PANTALLA", accent)
            ChipRow(WallpaperMode.values().toList(), s.wallpaperMode, { it.label }, accent) { s.wallpaperMode = it }
            when (s.wallpaperMode) {
                WallpaperMode.SYSTEM -> Hint("Muestra el fondo de pantalla que tengas en tu teléfono.")
                WallpaperMode.SOLID, WallpaperMode.STARS -> {
                    SliderRow("Color", s.wallHue1, 0f..360f, 0, accent, "${s.wallHue1.roundToInt()}°") { s.wallHue1 = it }
                    SliderRow("Brillo", s.wallBrightness, 0.02f..0.6f, 0, accent, "${(s.wallBrightness * 100).roundToInt()}%") { s.wallBrightness = it }
                }
                WallpaperMode.GRADIENT, WallpaperMode.ANIMATED_GRADIENT -> {
                    SliderRow("Color 1", s.wallHue1, 0f..360f, 0, accent, "${s.wallHue1.roundToInt()}°") { s.wallHue1 = it }
                    SliderRow("Color 2", s.wallHue2, 0f..360f, 0, accent, "${s.wallHue2.roundToInt()}°") { s.wallHue2 = it }
                    SliderRow("Brillo", s.wallBrightness, 0.02f..0.6f, 0, accent, "${(s.wallBrightness * 100).roundToInt()}%") { s.wallBrightness = it }
                }
                WallpaperMode.PHOTO -> {
                    Button(
                        onClick = onPickPhoto,
                        colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Color.Black)
                    ) { Text("Elegir foto de la galería") }
                    SliderRow("Oscurecer", s.photoDim, 0f..0.9f, 0, accent, "${(s.photoDim * 100).roundToInt()}%") { s.photoDim = it }
                    SliderRow("Desenfoque", s.photoBlur, 0f..24f, 0, accent, "${s.photoBlur.roundToInt()}") { s.photoBlur = it }
                    Hint("El desenfoque solo funciona en Android 12 o superior.")
                }
            }

            // ---------------- ANIMACIONES ----------------
            SectionTitle("ANIMACIONES", accent)
            Label("Al tocar una app")
            ChipRow(PressAnim.values().toList(), s.pressAnim, { it.label }, accent) { s.pressAnim = it }
            Label("Al aparecer la lista")
            ChipRow(EntranceAnim.values().toList(), s.entranceAnim, { it.label }, accent) { s.entranceAnim = it }
            Label("Al abrir una app")
            ChipRow(OpenAnim.values().toList(), s.openAnim, { it.label }, accent) { s.openAnim = it }
            SliderRow("Velocidad", s.animSpeed, 0.5f..2f, 0, accent, "x${"%.1f".format(s.animSpeed)}") { s.animSpeed = it }

            // ---------------- PANTALLA DE INICIO ----------------
            SectionTitle("PANTALLA DE INICIO", accent)
            SliderRow("Páginas", s.homePages.toFloat(), 1f..5f, 3, accent, "${s.homePages}") { v ->
                val n = v.roundToInt()
                if (n != s.homePages) {
                    s.homePages = n
                    s.reflowHome()
                }
            }
            SliderRow("Columnas", s.homeCols.toFloat(), 3f..6f, 2, accent, "${s.homeCols}") { v ->
                val n = v.roundToInt()
                if (n != s.homeCols) {
                    s.homeCols = n
                    s.reflowHome()
                }
            }
            SliderRow("Filas", s.homeRows.toFloat(), 4f..8f, 3, accent, "${s.homeRows}") { v ->
                val n = v.roundToInt()
                if (n != s.homeRows) {
                    s.homeRows = n
                    s.reflowHome()
                }
            }
            SwitchRow("Mostrar nombres en el inicio", s.homeLabels, accent) { s.homeLabels = it }
            SwitchRow("Mostrar dock", s.showDock, accent) { s.showDock = it }
            Hint("Mantén presionado un espacio vacío del inicio para añadir apps, widgets y carpetas, o para entrar al modo edición. Mantén presionada una app y arrástrala para moverla; si solo la sueltas, ves sus opciones. Si reduces páginas, columnas o filas, lo que no quepa se elimina.")

            // ---------------- DISEÑO ----------------
            SectionTitle("DISEÑO", accent)
            Label("Estilo de la lista de apps")
            ChipRow(DrawerStyle.values().toList(), s.drawerStyle, { it.label }, accent) { s.drawerStyle = it }
            SliderRow("Columnas (cuadrícula)", s.gridColumns.toFloat(), 3f..6f, 2, accent, "${s.gridColumns}") {
                s.gridColumns = it.roundToInt()
            }
            SwitchRow("Mostrar encabezado", s.showHeader, accent) { s.showHeader = it }
            SwitchRow("Mostrar búsqueda", s.showSearch, accent) { s.showSearch = it }
            SwitchRow("Mostrar favoritos", s.showFavorites, accent) { s.showFavorites = it }

            // ---------------- GESTOS ----------------
            SectionTitle("GESTOS", accent)
            Label("Deslizar hacia abajo")
            ChipRow(GestureAction.values().toList(), s.swipeDownAction, { it.label }, accent) { s.swipeDownAction = it }
            Label("Deslizar hacia arriba")
            ChipRow(GestureAction.values().toList(), s.swipeUpAction, { it.label }, accent) { s.swipeUpAction = it }
            Label("Doble toque en el fondo")
            ChipRow(GestureAction.values().toList(), s.doubleTapAction, { it.label }, accent) { s.doubleTapAction = it }
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = {
                    try {
                        ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Color.Black)
            ) { Text("Activar bloqueo de pantalla y gestos avanzados") }
            Hint("Bloquear pantalla, apps recientes y ajustes rápidos necesitan el servicio de accesibilidad de CyberHUD. En Accesibilidad, busca CyberHUD y actívalo. En Android 13 o superior, si aparece bloqueado, abre Ajustes > Apps > CyberHUD > menú de tres puntos > Permitir ajustes restringidos.")

            // ---------------- APPS OCULTAS ----------------
            SectionTitle("APPS OCULTAS", accent)
            val hiddenApps = apps.filter { s.hidden.contains(it.packageName) }
            if (hiddenApps.isEmpty()) {
                Hint("No tienes apps ocultas. Mantén presionada una app y elige \"Ocultar app\".")
            } else {
                hiddenApps.forEach { app ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(app.label, color = Color.White)
                        TextButton(onClick = { s.showApp(app.packageName) }) {
                            Text("Mostrar", color = accent)
                        }
                    }
                }
            }

            // ---------------- RESPALDO ----------------
            SectionTitle("RESPALDO", accent)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onExport,
                    colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Color.Black)
                ) { Text("Exportar") }
                Button(
                    onClick = onImport,
                    colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Color.Black)
                ) { Text("Importar") }
            }
            Hint("Guarda tu configuración en un archivo y recupérala después. Los widgets y la foto de fondo no se incluyen.")
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { confirmReset = true }) {
                Text("Restablecer todo", color = Color(0xFFFF5252))
            }
            Spacer(Modifier.height(40.dp))
        }
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Restablecer todo") },
            text = { Text("Se borrarán tema, fondo, favoritos, carpetas y widgets. ¿Continuar?") },
            confirmButton = {
                TextButton(onClick = { confirmReset = false; onReset() }) { Text("Restablecer") }
            },
            dismissButton = {
                TextButton(onClick = { confirmReset = false }) { Text("Cancelar") }
            }
        )
    }
}

@Composable
private fun SectionTitle(text: String, accent: Color) {
    Spacer(Modifier.height(22.dp))
    Text(text, color = accent, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
    Spacer(Modifier.height(8.dp))
}

@Composable
private fun Label(text: String) {
    Text(text, color = Color.LightGray, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp, bottom = 4.dp))
}

@Composable
private fun Hint(text: String) {
    Text(text, color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(vertical = 4.dp))
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, accent: Color, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = Color.White, fontSize = 14.sp)
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = accent, checkedThumbColor = Color.Black)
        )
    }
}

@Composable
private fun SliderRow(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    steps: Int,
    accent: Color,
    valueText: String,
    onChange: (Float) -> Unit
) {
    Column(Modifier.padding(vertical = 2.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = Color.White, fontSize = 14.sp)
            Text(valueText, color = accent, fontSize = 13.sp)
        }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onChange,
            valueRange = range,
            steps = steps,
            colors = SliderDefaults.colors(thumbColor = accent, activeTrackColor = accent)
        )
    }
}

@Composable
private fun <T> ChipRow(
    options: List<T>,
    selected: T,
    label: (T) -> String,
    accent: Color,
    onSelect: (T) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        options.forEach { option ->
            FilterChip(
                selected = option == selected,
                onClick = { onSelect(option) },
                label = { Text(label(option), fontSize = 12.sp) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = accent.copy(alpha = 0.35f),
                    selectedLabelColor = Color.White
                )
            )
        }
    }
}
