package com.yts.cyberhud

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.compose.runtime.mutableStateMapOf

class NexusNotificationListener : NotificationListenerService() {

    companion object {
        // Estado observable: la UI se recompone sola cuando cambia
        val activeNotifications = mutableStateMapOf<String, String>()
    }

    override fun onListenerConnected() {
        activeNotifications.clear()
        try {
            getActiveNotifications()?.forEach { sbn ->
                sbn.toText()?.let { activeNotifications[sbn.packageName] = it }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onListenerDisconnected() {
        activeNotifications.clear()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        sbn.toText()?.let { activeNotifications[sbn.packageName] = it }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        activeNotifications.remove(sbn.packageName)
    }

    private fun StatusBarNotification.toText(): String? {
        val extras = notification.extras ?: return null
        return extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()
            ?: extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()
    }
}
