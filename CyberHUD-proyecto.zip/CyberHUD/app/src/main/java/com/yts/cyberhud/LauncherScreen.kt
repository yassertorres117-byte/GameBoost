package com.yts.cyberhud

import android.accessibilityservice.AccessibilityService
import android.app.Activity
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar
import kotlin.math.ceil

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun NexusLauncherScreen(
    s: LauncherSettings,
    appWidgetManager: AppWidgetManager,
    appWidgetHost: AppWidgetHost,
    homeSignal: Int
) {
    val context = LocalContext.current
    val view = LocalView.current
    val scope = rememberCoroutineScope()
    val palette = remember(s.accent, s.theme) { ThemeColors(s.accent, s.theme.containerBg) }

    var appsList by remember { mutableStateOf<List<AppInfo>>(emptyList()) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf(AppCategory.TODAS) }
    var showDrawer by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var showRadialMenu by remember { mutableStateOf(false) }
    var homeEditMode by remember { mutableStateOf(false) }

    var selectedFolderName by remember { mutableStateOf<String?>(null) }
    var menuApp by remember { mutableStateOf<AppInfo?>(null) }
    var folderPickApp by remember { mutableStateOf<AppInfo?>(null) }
    var showNewFolder by remember { mutableStateOf(false) }
    var folderToDelete by remember { mutableStateOf<String?>(null) }

    var currentTime by remember { mutableStateOf(getCurrentTimeString()) }
    var currentDateString by remember { mutableStateOf(getFullDateString()) }
    var batteryLevel by remember { mutableStateOf(getBatteryPercentage(context)) }
    var ramAvailableMB by remember { mutableStateOf(getAvailableRAM(context)) }
    var storageAvailableGB by remember { mutableStateOf(getAvailableStorageGB()) }
    var currentHour by remember { mutableStateOf(Calendar.getInstance().get(Calendar.HOUR_OF_DAY)) }

    val iconPacks = remember(showSettings) { findIconPacks(context) }

    val open: (String) -> Unit = { pkg ->
        showDrawer = false
        launchApp(context, view, pkg, s.openAnim)
    }

    fun toast(msg: String) {
        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
    }

    fun perform(action: GestureAction) {
        when (action) {
            GestureAction.NONE -> {}
            GestureAction.OPEN_DRAWER -> showDrawer = true
            GestureAction.NOTIFICATIONS -> openNotificationShade(context)
            GestureAction.QUICK_SETTINGS -> runGlobalAction(context, AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS)
            GestureAction.LOCK_SCREEN -> {
                if (Build.VERSION.SDK_INT >= 28) {
                    runGlobalAction(context, AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
                } else {
                    toast("Bloquear pantalla requiere Android 9 o superior")
                }
            }
            GestureAction.RECENTS -> runGlobalAction(context, AccessibilityService.GLOBAL_ACTION_RECENTS)
            GestureAction.SETTINGS -> showSettings = true
            GestureAction.SYSTEM_SETTINGS -> openSettings(context)
            GestureAction.QUICK_MENU -> showRadialMenu = true
        }
    }

    // ---------------- Widgets: selector y configuración ----------------
    var widgetTarget by remember { mutableStateOf(Triple(0, -1, -1)) }
    var pendingWidgetId by remember { mutableStateOf(-1) }

    fun finishWidget(id: Int) {
        val info = appWidgetManager.getAppWidgetInfo(id)
        val dm = context.resources.displayMetrics
        val d = dm.density
        val cellW = (dm.widthPixels / d - 16f) / s.homeCols
        val cellH = (dm.heightPixels / d - 330f) / s.homeRows
        val sc = if (info != null && cellW > 0f) ceil((info.minWidth / d) / cellW).toInt().coerceAtLeast(1) else 2
        val sr = if (info != null && cellH > 0f) ceil((info.minHeight / d) / cellH).toInt().coerceAtLeast(1) else 1
        val ok = s.addHomeItem("widget", id.toString(), sc, sr, widgetTarget.first, widgetTarget.second, widgetTarget.third)
        if (!ok) {
            appWidgetHost.deleteAppWidgetId(id)
            toast("No hay espacio para ese widget")
        }
    }

    val configureLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            finishWidget(pendingWidgetId)
        } else {
            appWidgetHost.deleteAppWidgetId(pendingWidgetId)
        }
        pendingWidgetId = -1
    }

    val widgetPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val id = result.data?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, pendingWidgetId) ?: pendingWidgetId
        if (result.resultCode != Activity.RESULT_OK || id == -1) {
            if (id != -1) appWidgetHost.deleteAppWidgetId(id)
            pendingWidgetId = -1
            return@rememberLauncherForActivityResult
        }
        pendingWidgetId = id
        val info = appWidgetManager.getAppWidgetInfo(id)
        if (info?.configure != null) {
            val cfg = Intent(AppWidgetManager.ACTION_APPWIDGET_CONFIGURE).apply {
                component = info.configure
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            }
            try {
                configureLauncher.launch(cfg)
            } catch (e: Exception) {
                e.printStackTrace()
                appWidgetHost.deleteAppWidgetId(id)
                pendingWidgetId = -1
            }
        } else {
            finishWidget(id)
            pendingWidgetId = -1
        }
    }

    val requestWidget: (Int, Int, Int) -> Unit = { page, col, row ->
        widgetTarget = Triple(page, col, row)
        val id = appWidgetHost.allocateAppWidgetId()
        pendingWidgetId = id
        val pickIntent = Intent(AppWidgetManager.ACTION_APPWIDGET_PICK).apply {
            putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
        }
        widgetPickerLauncher.launch(pickIntent)
    }

    // ---------------- Foto de fondo, exportar e importar ----------------
    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            s.photoUri = uri.toString()
            s.wallpaperMode = WallpaperMode.PHOTO
        }
    }

    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val json = exportPrefs(context)
                context.contentResolver.openOutputStream(uri)?.use { it.write(json.toByteArray()) }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val text = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                if (text != null && importPrefs(context, text)) {
                    (context as? Activity)?.recreate()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // ---------------- Datos en vivo ----------------
    LaunchedEffect(s.iconPack) {
        appsList = withContext(Dispatchers.IO) { getInstalledApps(context, s.iconPack) }
    }

    LaunchedEffect(Unit) {
        var tick = 0
        while (true) {
            currentTime = getCurrentTimeString()
            if (tick % 5 == 0) {
                currentDateString = getFullDateString()
                batteryLevel = getBatteryPercentage(context)
                ramAvailableMB = getAvailableRAM(context)
                storageAvailableGB = getAvailableStorageGB()
                currentHour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            }
            tick++
            delay(1000)
        }
    }

    // Al pulsar el botón Inicio: cerrar cajón, ajustes y menús
    LaunchedEffect(homeSignal) {
        if (homeSignal > 0) {
            showDrawer = false
            showSettings = false
            showRadialMenu = false
            menuApp = null
            homeEditMode = false
            searchQuery = ""
            selectedFolderName = null
        }
    }

    // Refrescar la lista al instalar o desinstalar apps
    DisposableEffect(Unit) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, intent: Intent?) {
                scope.launch {
                    appsList = withContext(Dispatchers.IO) { getInstalledApps(context, s.iconPack) }
                }
            }
        }
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(context, receiver, filter, ContextCompat.RECEIVER_EXPORTED)
        onDispose { context.unregisterReceiver(receiver) }
    }

    // Botón atrás: un launcher nunca se cierra
    BackHandler(enabled = true) {
        when {
            menuApp != null -> menuApp = null
            showSettings -> showSettings = false
            showRadialMenu -> showRadialMenu = false
            showDrawer && selectedFolderName != null -> selectedFolderName = null
            showDrawer && searchQuery.isNotEmpty() -> searchQuery = ""
            showDrawer -> showDrawer = false
            homeEditMode -> homeEditMode = false
            else -> { /* no hacer nada */ }
        }
    }

    val visibleApps = remember(appsList, s.hidden) {
        appsList.filter { !s.hidden.contains(it.packageName) }
    }

    val timeBasedFavorites = remember(currentHour, visibleApps, s.favorites) {
        if (s.favorites.isNotEmpty()) {
            visibleApps.filter { s.favorites.contains(it.packageName) }
        } else {
            visibleApps.filter { app ->
                val pkg = app.packageName.lowercase()
                if (currentHour in 6..13) {
                    pkg.contains("whatsapp") || pkg.contains("mail") || pkg.contains("chrome") || pkg.contains("clock")
                } else {
                    pkg.contains("game") || pkg.contains("freefire") || pkg.contains("youtube") || pkg.contains("tiktok")
                }
            }.take(5)
        }
    }

    val filteredApps = remember(searchQuery, selectedCategory, visibleApps, s.favorites) {
        visibleApps.map { it.copy(isFavorite = s.favorites.contains(it.packageName)) }
            .filter { app ->
                val matchesCategory = selectedCategory == AppCategory.TODAS || app.category == selectedCategory
                val matchesSearch = app.label.contains(searchQuery, ignoreCase = true)
                matchesCategory && matchesSearch
            }
    }

    val isFocus = s.engineMode == LauncherEngineMode.FOCUS_MINIMAL
    val effectiveStyle = if (isFocus) DrawerStyle.TEXT else s.drawerStyle
    val live = LiveInfo(currentTime, currentDateString, batteryLevel, ramAvailableMB, storageAvailableGB)

    Box(modifier = Modifier.fillMaxSize()) {

        // ---------------- Pantalla de inicio ----------------
        HomeScreen(
            s = s,
            palette = palette,
            apps = appsList,
            live = live,
            appWidgetHost = appWidgetHost,
            appWidgetManager = appWidgetManager,
            homeSignal = homeSignal,
            editMode = homeEditMode,
            onEditModeChange = { homeEditMode = it },
            onOpenApp = open,
            onOpenDrawer = { showDrawer = true },
            onAddWidget = requestWidget,
            onPerform = { perform(it) },
            onOpenSettings = { showSettings = true },
            onOpenNotificationSettings = { openNotificationListenerSettings(context) }
        )

        // ---------------- Cajón de apps ----------------
        AnimatedVisibility(
            visible = showDrawer,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.78f))
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Aplicaciones",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = {
                        s.drawerStyle = DrawerStyle.values()[(s.drawerStyle.ordinal + 1) % DrawerStyle.values().size]
                    }) {
                        Icon(
                            imageVector = when (s.drawerStyle) {
                                DrawerStyle.LIST -> Icons.Default.List
                                DrawerStyle.GRID -> Icons.Default.Apps
                                DrawerStyle.TEXT -> Icons.Default.Menu
                            },
                            contentDescription = "Vista",
                            tint = palette.primaryColor
                        )
                    }
                    IconButton(onClick = { showDrawer = false }) {
                        Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Cerrar", tint = palette.primaryColor)
                    }
                }

                if (s.showSearch) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Buscar aplicación...", color = Color.Gray) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = palette.primaryColor) },
                        singleLine = true,
                        shape = RoundedCornerShape(24.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = palette.primaryColor,
                            unfocusedBorderColor = Color(0xFF2A2A35),
                            focusedContainerColor = Color(0xCC121218),
                            unfocusedContainerColor = Color(0xCC121218)
                        )
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                }

                if (s.showFavorites && timeBasedFavorites.isNotEmpty() && searchQuery.isEmpty() && !isFocus) {
                    Text(
                        text = if (s.favorites.isNotEmpty()) "FAVORITOS DE ACCESO RÁPIDO" else "SUGERIDOS POR LA HORA (${currentHour}h)",
                        color = palette.primaryColor,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
                    )
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(timeBasedFavorites, key = { it.packageName }) { app ->
                            FavoriteItemChip(app = app, s = s, palette = palette, onClick = { open(app.packageName) })
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                }

                if (!isFocus) {
                    ScrollableTabRow(
                        selectedTabIndex = selectedCategory.ordinal,
                        containerColor = Color.Transparent,
                        contentColor = palette.primaryColor,
                        edgePadding = 0.dp
                    ) {
                        AppCategory.values().forEach { category ->
                            Tab(
                                selected = selectedCategory == category,
                                onClick = {
                                    selectedCategory = category
                                    if (category != AppCategory.CARPETAS) selectedFolderName = null
                                },
                                text = {
                                    Text(
                                        text = category.title,
                                        fontWeight = if (selectedCategory == category) FontWeight.Bold else FontWeight.Normal
                                    )
                                }
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                }

                if (selectedCategory == AppCategory.CARPETAS && !isFocus) {
                    val folders = s.folders
                    val folder = folders.firstOrNull { it.name == selectedFolderName }
                    if (folder == null) {
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            item {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(14.dp))
                                        .background(palette.primaryColor.copy(alpha = 0.15f))
                                        .clickable { showNewFolder = true }
                                        .padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, tint = palette.primaryColor)
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Text("Nueva carpeta", color = palette.primaryColor, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            if (folders.isEmpty()) {
                                item {
                                    Text(
                                        "Aún no tienes carpetas. Crea una y luego mantén presionada una app para añadirla.",
                                        color = Color.Gray,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                            items(folders, key = { it.name }) { f ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(14.dp))
                                        .background(palette.containerBg)
                                        .combinedClickable(
                                            onClick = { selectedFolderName = f.name },
                                            onLongClick = { folderToDelete = f.name }
                                        )
                                        .padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Folder, contentDescription = null, tint = palette.primaryColor)
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Text(text = f.name, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                    Text(text = "${f.packageNames.size}", color = Color.Gray, fontSize = 12.sp)
                                }
                            }
                        }
                    } else {
                        Column(modifier = Modifier.fillMaxSize()) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 12.dp)
                            ) {
                                Text(
                                    text = "< Volver",
                                    color = palette.primaryColor,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.clickable { selectedFolderName = null }
                                )
                                Spacer(modifier = Modifier.width(16.dp))
                                Text(text = folder.name, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            }
                            val folderApps = visibleApps
                                .filter { folder.packageNames.contains(it.packageName) }
                                .map { it.copy(isFavorite = s.favorites.contains(it.packageName)) }
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(folderApps, key = { it.packageName }) { app ->
                                    AppRowItem(
                                        app = app,
                                        s = s,
                                        palette = palette,
                                        onClick = { open(app.packageName) },
                                        onLongClick = { menuApp = app }
                                    )
                                }
                            }
                        }
                    }
                } else if (effectiveStyle == DrawerStyle.TEXT) {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(filteredApps, key = { it.packageName }) { app ->
                            Text(
                                text = app.label,
                                color = Color.White,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Light,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .entrance(s)
                                    .combinedClickable(
                                        onClick = { open(app.packageName) },
                                        onLongClick = { menuApp = app }
                                    )
                                    .padding(vertical = 4.dp, horizontal = 8.dp)
                            )
                        }
                    }
                } else if (effectiveStyle == DrawerStyle.GRID) {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(s.gridColumns.coerceIn(3, 6)),
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(filteredApps, key = { it.packageName }) { app ->
                            AppGridItem(
                                app = app,
                                s = s,
                                palette = palette,
                                onClick = { open(app.packageName) },
                                onLongClick = { menuApp = app }
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(filteredApps, key = { it.packageName }) { app ->
                            AppRowItem(
                                app = app,
                                s = s,
                                palette = palette,
                                onClick = { open(app.packageName) },
                                onLongClick = { menuApp = app }
                            )
                        }
                    }
                }
            }
        }

        // ---------------- Menú rápido (circular) ----------------
        AnimatedVisibility(
            visible = showRadialMenu,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.85f))
                    .clickable { showRadialMenu = false },
                contentAlignment = Alignment.Center
            ) {
                RadialCommandDial(
                    palette = palette,
                    onOptionSelected = { action ->
                        showRadialMenu = false
                        when (action) {
                            "LAUNCHER" -> showSettings = true
                            "SYSTEM" -> openSettings(context)
                            "NOTIFICATIONS" -> openNotificationShade(context)
                            "THEMES" -> showSettings = true
                        }
                    }
                )
            }
        }

        // ---------------- Ajustes (encima de todo) ----------------
        AnimatedVisibility(
            visible = showSettings,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            SettingsScreen(
                s = s,
                palette = palette,
                apps = appsList,
                iconPacks = iconPacks,
                onPickPhoto = { photoPicker.launch(arrayOf("image/*")) },
                onExport = { exportLauncher.launch("cyberhud-respaldo.json") },
                onImport = { importLauncher.launch(arrayOf("*/*")) },
                onReset = {
                    context.launcherPrefs().edit().clear().apply()
                    (context as? Activity)?.recreate()
                },
                onClose = { showSettings = false }
            )
        }
    }

    // ---------------- Diálogos del cajón ----------------

    menuApp?.let { app ->
        val inFolder = selectedFolderName
        AlertDialog(
            onDismissRequest = { menuApp = null },
            confirmButton = {},
            title = { Text(app.label) },
            text = {
                Column {
                    MenuOption("Añadir a pantalla de inicio") {
                        if (s.addHomeItem("app", app.packageName)) {
                            toast("Añadida al inicio")
                            showDrawer = false
                        } else {
                            toast("No hay espacio en el inicio")
                        }
                        menuApp = null
                    }
                    MenuOption("Añadir al dock") {
                        if (s.addDock(app.packageName)) toast("Añadida al dock") else toast("El dock está lleno o ya la tiene")
                        menuApp = null
                    }
                    MenuOption(if (s.favorites.contains(app.packageName)) "Quitar de favoritos" else "Añadir a favoritos") {
                        s.toggleFavorite(app.packageName)
                        menuApp = null
                    }
                    MenuOption("Añadir a carpeta") {
                        folderPickApp = app
                        menuApp = null
                    }
                    if (inFolder != null && selectedCategory == AppCategory.CARPETAS) {
                        MenuOption("Quitar de esta carpeta") {
                            s.removeFromFolder(inFolder, app.packageName)
                            menuApp = null
                        }
                    }
                    MenuOption("Ocultar app") {
                        s.hideApp(app.packageName)
                        menuApp = null
                    }
                    MenuOption("Información de la app") {
                        openAppInfo(context, app.packageName)
                        menuApp = null
                    }
                    MenuOption("Desinstalar") {
                        uninstallApp(context, app.packageName)
                        menuApp = null
                    }
                }
            }
        )
    }

    folderPickApp?.let { app ->
        val folders = s.folders
        AlertDialog(
            onDismissRequest = { folderPickApp = null },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { folderPickApp = null }) { Text("Cancelar") } },
            title = { Text("Añadir ${app.label} a...") },
            text = {
                if (folders.isEmpty()) {
                    Text("Primero crea una carpeta en la pestaña Carpetas.")
                } else {
                    Column {
                        folders.forEach { f ->
                            MenuOption(f.name) {
                                s.addToFolder(f.name, app.packageName)
                                folderPickApp = null
                            }
                        }
                    }
                }
            }
        )
    }

    if (showNewFolder) {
        var newName by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showNewFolder = false },
            title = { Text("Nueva carpeta") },
            text = {
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    singleLine = true,
                    placeholder = { Text("Nombre") }
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    s.addFolder(newName)
                    showNewFolder = false
                }) { Text("Crear") }
            },
            dismissButton = { TextButton(onClick = { showNewFolder = false }) { Text("Cancelar") } }
        )
    }

    folderToDelete?.let { name ->
        AlertDialog(
            onDismissRequest = { folderToDelete = null },
            title = { Text("Eliminar carpeta") },
            text = { Text("¿Eliminar \"$name\"? Las apps no se desinstalan.") },
            confirmButton = {
                TextButton(onClick = {
                    s.deleteFolder(name)
                    folderToDelete = null
                }) { Text("Eliminar") }
            },
            dismissButton = { TextButton(onClick = { folderToDelete = null }) { Text("Cancelar") } }
        )
    }
}

// ---------------- Utilidades ----------------

/** Ejecuta una acción global (bloquear, recientes...) usando el servicio de accesibilidad. */
fun runGlobalAction(context: Context, action: Int) {
    val svc = NexusAccessibilityService.instance
    if (svc == null) {
        Toast.makeText(
            context,
            "Activa CyberHUD en Ajustes > Accesibilidad para usar este gesto",
            Toast.LENGTH_LONG
        ).show()
        try {
            context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    } else {
        svc.performGlobalAction(action)
    }
}

fun openAppInfo(context: Context, pkg: String) {
    try {
        context.startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (e: Exception) {
        e.printStackTrace()
    }
}

fun uninstallApp(context: Context, pkg: String) {
    try {
        context.startActivity(
            Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (e: Exception) {
        e.printStackTrace()
    }
}
