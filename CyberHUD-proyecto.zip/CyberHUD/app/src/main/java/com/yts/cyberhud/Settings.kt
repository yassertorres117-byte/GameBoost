package com.yts.cyberhud

import android.content.ComponentName
import android.content.Context
import android.content.SharedPreferences
import android.graphics.drawable.Drawable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp
import java.util.UUID
import org.json.JSONArray
import org.json.JSONObject
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

// ---------------- Enums de personalización ----------------

enum class NeonTheme(val label: String, val primaryColor: Color, val containerBg: Color) {
    CYBER_CYAN("Cyber Cyan", Color(0xFF00E5FF), Color(0xFF12121A)),
    MATRIX_GREEN("Matrix Green", Color(0xFF00FF66), Color(0xFF0D180F)),
    SYNTH_PURPLE("Synthwave Purple", Color(0xFFD500F9), Color(0xFF180D1C)),
    BLOOD_RED("Blood Red", Color(0xFFFF1744), Color(0xFF1C0D0D)),
    AMOLED_GOLD("AMOLED Gold", Color(0xFFFFD700), Color(0xFF14120B))
}

enum class LauncherEngineMode(val label: String) {
    NEXUS_HUD("Cyber HUD"),
    PIXEL_AT_A_GLANCE("Pixel Smart Feed"),
    AIO_HACKER("AIO System Monitor"),
    FOCUS_MINIMAL("Focus Minimalist")
}

enum class AppCategory(val title: String) {
    TODAS("Todas"),
    JUEGOS("Juegos"),
    SOCIAL("Social"),
    HERRAMIENTAS("Herramientas"),
    CARPETAS("Carpetas")
}

enum class IconShape(val label: String, val shape: Shape) {
    ORIGINAL("Original", RoundedCornerShape(0.dp)),
    CIRCLE("Círculo", CircleShape),
    ROUNDED("Redondeado", RoundedCornerShape(percent = 28)),
    SQUARE("Cuadrado", RoundedCornerShape(6.dp)),
    LEAF("Hoja", RoundedCornerShape(topStartPercent = 50, topEndPercent = 12, bottomEndPercent = 50, bottomStartPercent = 12))
}

enum class DrawerStyle(val label: String) {
    LIST("Lista"),
    GRID("Cuadrícula"),
    TEXT("Solo texto")
}

enum class PressAnim(val label: String) {
    BOUNCE("Rebote"),
    SOFT("Suave"),
    NONE("Ninguna")
}

enum class EntranceAnim(val label: String) {
    NONE("Ninguna"),
    FADE("Aparecer"),
    SLIDE_UP("Subir"),
    ZOOM("Zoom")
}

enum class OpenAnim(val label: String) {
    ZOOM("Zoom"),
    FADE("Fundido"),
    SLIDE("Deslizar"),
    NONE("Ninguna")
}

enum class WallpaperMode(val label: String) {
    SYSTEM("Del sistema"),
    SOLID("Color"),
    GRADIENT("Degradado"),
    ANIMATED_GRADIENT("Degradado animado"),
    STARS("Estrellas"),
    PHOTO("Mi foto")
}

enum class GestureAction(val label: String) {
    NONE("Nada"),
    OPEN_DRAWER("Abrir cajón de apps"),
    NOTIFICATIONS("Cortina"),
    QUICK_SETTINGS("Ajustes rápidos"),
    LOCK_SCREEN("Bloquear pantalla"),
    RECENTS("Apps recientes"),
    SETTINGS("Ajustes del launcher"),
    SYSTEM_SETTINGS("Ajustes del sistema"),
    QUICK_MENU("Menú rápido")
}

// ---------------- Modelos ----------------

data class AppFolder(
    val name: String,
    val packageNames: List<String>
)

data class AppInfo(
    val label: String,
    val packageName: String,
    val component: ComponentName,
    val icon: Drawable,
    val category: AppCategory,
    val isFavorite: Boolean = false
)

/** Elemento colocado en la pantalla de inicio. type: "app", "widget" o "folder". */
data class HomeItem(
    val id: String,
    val page: Int,
    val col: Int,
    val row: Int,
    val spanC: Int,
    val spanR: Int,
    val type: String,
    val ref: String
)

class ThemeColors(val primaryColor: Color, val containerBg: Color)

// ---------------- Persistencia ----------------

const val PREFS_NAME = "nexus_prefs"

fun Context.launcherPrefs(): SharedPreferences =
    getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

class LauncherSettings(context: Context) {

    private val prefs = context.launcherPrefs()

    private inner class BoolPref(private val key: String, def: Boolean) : ReadWriteProperty<Any?, Boolean> {
        private var state by mutableStateOf(prefs.getBoolean(key, def))
        override fun getValue(thisRef: Any?, property: KProperty<*>): Boolean = state
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Boolean) {
            state = value
            prefs.edit().putBoolean(key, value).apply()
        }
    }

    private inner class IntPref(private val key: String, def: Int) : ReadWriteProperty<Any?, Int> {
        private var state by mutableStateOf(prefs.getInt(key, def))
        override fun getValue(thisRef: Any?, property: KProperty<*>): Int = state
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Int) {
            state = value
            prefs.edit().putInt(key, value).apply()
        }
    }

    private inner class FloatPref(private val key: String, def: Float) : ReadWriteProperty<Any?, Float> {
        private var state by mutableStateOf(prefs.getFloat(key, def))
        override fun getValue(thisRef: Any?, property: KProperty<*>): Float = state
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Float) {
            state = value
            prefs.edit().putFloat(key, value).apply()
        }
    }

    private inner class StrPref(private val key: String, def: String) : ReadWriteProperty<Any?, String> {
        private var state by mutableStateOf(prefs.getString(key, def) ?: def)
        override fun getValue(thisRef: Any?, property: KProperty<*>): String = state
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: String) {
            state = value
            prefs.edit().putString(key, value).apply()
        }
    }

    private inner class SetPref(private val key: String) : ReadWriteProperty<Any?, Set<String>> {
        private var state by mutableStateOf((prefs.getStringSet(key, emptySet()) ?: emptySet()).toSet())
        override fun getValue(thisRef: Any?, property: KProperty<*>): Set<String> = state
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Set<String>) {
            state = value
            prefs.edit().putStringSet(key, HashSet(value)).apply()
        }
    }

    private inner class EnumPref<E : Enum<E>>(
        private val key: String,
        private val def: E,
        private val all: Array<E>
    ) : ReadWriteProperty<Any?, E> {
        private var state by mutableStateOf(
            all.firstOrNull { it.name == prefs.getString(key, null) } ?: def
        )
        override fun getValue(thisRef: Any?, property: KProperty<*>): E = state
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: E) {
            state = value
            prefs.edit().putString(key, value.name).apply()
        }
    }

    // --- Apariencia ---
    var theme: NeonTheme by EnumPref("theme", NeonTheme.CYBER_CYAN, NeonTheme.values())
    var accentHue: Float by FloatPref("accentHue", -1f) // -1 = usar el color del tema
    var engineMode: LauncherEngineMode by EnumPref("mode", LauncherEngineMode.NEXUS_HUD, LauncherEngineMode.values())

    // --- Íconos ---
    var iconShape: IconShape by EnumPref("iconShape", IconShape.ORIGINAL, IconShape.values())
    var iconSize: Float by FloatPref("iconSize", 46f)
    var showLabels: Boolean by BoolPref("showLabels", true)
    var iconPack: String by StrPref("iconPack", "")

    // --- Fondo ---
    var wallpaperMode: WallpaperMode by EnumPref("wallMode", WallpaperMode.SOLID, WallpaperMode.values())
    var wallHue1: Float by FloatPref("wallHue1", 240f)
    var wallHue2: Float by FloatPref("wallHue2", 280f)
    var wallBrightness: Float by FloatPref("wallBright", 0.08f)
    var photoUri: String by StrPref("photoUri", "")
    var photoDim: Float by FloatPref("photoDim", 0.35f)
    var photoBlur: Float by FloatPref("photoBlur", 0f)

    // --- Animaciones ---
    var pressAnim: PressAnim by EnumPref("pressAnim", PressAnim.BOUNCE, PressAnim.values())
    var entranceAnim: EntranceAnim by EnumPref("entranceAnim", EntranceAnim.FADE, EntranceAnim.values())
    var openAnim: OpenAnim by EnumPref("openAnim", OpenAnim.ZOOM, OpenAnim.values())
    var animSpeed: Float by FloatPref("animSpeed", 1f)

    // --- Diseño ---
    var drawerStyle: DrawerStyle by EnumPref("drawerStyle", DrawerStyle.LIST, DrawerStyle.values())
    var gridColumns: Int by IntPref("gridColumns", 4)
    var showHeader: Boolean by BoolPref("showHeader", true)
    var showSearch: Boolean by BoolPref("showSearch", true)
    var showFavorites: Boolean by BoolPref("showFavorites", true)

    // --- Gestos ---
    var swipeDownAction: GestureAction by EnumPref("swipeDown", GestureAction.NOTIFICATIONS, GestureAction.values())
    var longPressAction: GestureAction by EnumPref("longPress", GestureAction.QUICK_MENU, GestureAction.values())
    var doubleTapAction: GestureAction by EnumPref("doubleTap", GestureAction.NONE, GestureAction.values())
    var swipeUpAction: GestureAction by EnumPref("swipeUp", GestureAction.OPEN_DRAWER, GestureAction.values())

    // --- Pantalla de inicio ---
    var homeCols: Int by IntPref("homeCols", 4)
    var homeRows: Int by IntPref("homeRows", 6)
    var homePages: Int by IntPref("homePages", 2)
    var homeLabels: Boolean by BoolPref("homeLabels", true)
    var showDock: Boolean by BoolPref("showDock", true)

    // --- Apps ---
    var favorites: Set<String> by SetPref("favs")
    var hidden: Set<String> by SetPref("hidden")
    private var foldersJson: String by StrPref("folders", "[]")
    private var homeJson: String by StrPref("homeItems", "[]")
    private var dockJson: String by StrPref("dock", "[]")

    val homeItems: List<HomeItem>
        get() = parseHome(homeJson)

    val dockPackages: List<String>
        get() = parseStringList(dockJson)

    val accent: Color
        get() = if (accentHue >= 0f) Color.hsv(accentHue.coerceIn(0f, 360f), 0.85f, 1f) else theme.primaryColor

    val folders: List<AppFolder>
        get() = parseFolders(foldersJson)

    fun toggleFavorite(pkg: String) {
        favorites = if (favorites.contains(pkg)) favorites - pkg else favorites + pkg
    }

    fun hideApp(pkg: String) {
        hidden = hidden + pkg
        favorites = favorites - pkg
    }

    fun showApp(pkg: String) {
        hidden = hidden - pkg
    }

    fun addFolder(name: String) {
        val clean = name.trim()
        if (clean.isEmpty() || folders.any { it.name == clean }) return
        foldersJson = foldersToJson(folders + AppFolder(clean, emptyList()))
    }

    fun deleteFolder(name: String) {
        foldersJson = foldersToJson(folders.filter { it.name != name })
    }

    fun addToFolder(folderName: String, pkg: String) {
        foldersJson = foldersToJson(folders.map {
            if (it.name == folderName && !it.packageNames.contains(pkg)) it.copy(packageNames = it.packageNames + pkg) else it
        })
    }

    fun removeFromFolder(folderName: String, pkg: String) {
        foldersJson = foldersToJson(folders.map {
            if (it.name == folderName) it.copy(packageNames = it.packageNames - pkg) else it
        })
    }

    // ---------------- Pantalla de inicio: lógica de cuadrícula ----------------

    private fun fits(list: List<HomeItem>, page: Int, col: Int, row: Int, sc: Int, sr: Int, ignoreId: String?): Boolean {
        if (col < 0 || row < 0 || col + sc > homeCols || row + sr > homeRows) return false
        return list.none { o ->
            o.id != ignoreId && o.page == page &&
                col < o.col + o.spanC && col + sc > o.col &&
                row < o.row + o.spanR && row + sr > o.row
        }
    }

    private fun findFree(list: List<HomeItem>, page: Int, sc: Int, sr: Int, prefCol: Int, prefRow: Int): Pair<Int, Int>? {
        if (prefCol >= 0 && prefRow >= 0 && fits(list, page, prefCol, prefRow, sc, sr, null)) {
            return Pair(prefCol, prefRow)
        }
        for (r in 0..(homeRows - sr)) {
            for (c in 0..(homeCols - sc)) {
                if (fits(list, page, c, r, sc, sr, null)) return Pair(c, r)
            }
        }
        return null
    }

    /** Añade un elemento a la pantalla de inicio. Devuelve false si no hay espacio. */
    fun addHomeItem(type: String, ref: String, sc: Int = 1, sr: Int = 1, page: Int = 0, col: Int = -1, row: Int = -1): Boolean {
        val list = homeItems
        val spanC = sc.coerceIn(1, homeCols)
        val spanR = sr.coerceIn(1, homeRows)
        val first = page.coerceIn(0, homePages - 1)
        val order = listOf(first) + (0 until homePages).filter { it != first }
        for ((i, p) in order.withIndex()) {
            val pos = findFree(list, p, spanC, spanR, if (i == 0) col else -1, if (i == 0) row else -1) ?: continue
            homeJson = homeToJson(list + HomeItem(UUID.randomUUID().toString(), p, pos.first, pos.second, spanC, spanR, type, ref))
            return true
        }
        return false
    }

    fun moveHomeItem(id: String, col: Int, row: Int): Boolean {
        val list = homeItems
        val item = list.firstOrNull { it.id == id } ?: return false
        if (!fits(list, item.page, col, row, item.spanC, item.spanR, id)) return false
        homeJson = homeToJson(list.map { if (it.id == id) it.copy(col = col, row = row) else it })
        return true
    }

    fun moveHomeItemToPage(id: String, page: Int): Boolean {
        val list = homeItems
        val item = list.firstOrNull { it.id == id } ?: return false
        if (page < 0 || page >= homePages) return false
        val others = list.filter { it.id != id }
        val pos = findFree(others, page, item.spanC, item.spanR, -1, -1) ?: return false
        homeJson = homeToJson(list.map { if (it.id == id) it.copy(page = page, col = pos.first, row = pos.second) else it })
        return true
    }

    fun resizeHomeItem(id: String, sc: Int, sr: Int): Boolean {
        val list = homeItems
        val item = list.firstOrNull { it.id == id } ?: return false
        if (!fits(list, item.page, item.col, item.row, sc, sr, id)) return false
        homeJson = homeToJson(list.map { if (it.id == id) it.copy(spanC = sc, spanR = sr) else it })
        return true
    }

    fun removeHomeItem(id: String) {
        homeJson = homeToJson(homeItems.filter { it.id != id })
    }

    /** Reacomoda todo cuando cambian páginas, columnas o filas. Lo que no quepa se elimina. */
    fun reflowHome() {
        val placed = mutableListOf<HomeItem>()
        for (original in homeItems) {
            var item = original.copy(
                page = original.page.coerceIn(0, homePages - 1),
                spanC = original.spanC.coerceIn(1, homeCols),
                spanR = original.spanR.coerceIn(1, homeRows)
            )
            if (!fits(placed, item.page, item.col, item.row, item.spanC, item.spanR, null)) {
                var spot: Triple<Int, Int, Int>? = null
                for (p in 0 until homePages) {
                    val f = findFree(placed, p, item.spanC, item.spanR, -1, -1)
                    if (f != null) {
                        spot = Triple(p, f.first, f.second)
                        break
                    }
                }
                if (spot == null) continue
                item = item.copy(page = spot.first, col = spot.second, row = spot.third)
            }
            placed += item
        }
        homeJson = homeToJson(placed)
    }

    // ---------------- Dock ----------------

    fun addDock(pkg: String): Boolean {
        val dock = dockPackages
        if (dock.contains(pkg) || dock.size >= 5) return false
        dockJson = stringListToJson(dock + pkg)
        return true
    }

    fun removeDock(pkg: String) {
        dockJson = stringListToJson(dockPackages - pkg)
    }
}

// ---------------- Carpetas (JSON) ----------------

fun parseFolders(json: String): List<AppFolder> = try {
    val arr = JSONArray(json)
    (0 until arr.length()).map { i ->
        val o = arr.getJSONObject(i)
        val pk = o.getJSONArray("pkgs")
        AppFolder(o.getString("name"), (0 until pk.length()).map { pk.getString(it) })
    }
} catch (e: Exception) {
    emptyList()
}

fun foldersToJson(list: List<AppFolder>): String {
    val arr = JSONArray()
    list.forEach { f ->
        arr.put(JSONObject().put("name", f.name).put("pkgs", JSONArray(f.packageNames)))
    }
    return arr.toString()
}

// ---------------- Widgets (IDs) ----------------

fun loadWidgets(context: Context): List<Int> =
    context.launcherPrefs().getString("widgets", "")!!
        .split(",").mapNotNull { it.toIntOrNull() }

fun saveWidgets(context: Context, ids: List<Int>) {
    context.launcherPrefs().edit().putString("widgets", ids.joinToString(",")).apply()
}

// ---------------- Respaldo ----------------

private val BACKUP_EXCLUDED = setOf("widgets", "photoUri")

fun exportPrefs(context: Context): String {
    val root = JSONObject()
    for ((k, v) in context.launcherPrefs().all) {
        if (k in BACKUP_EXCLUDED) continue
        val o = JSONObject()
        when (v) {
            is Boolean -> { o.put("t", "b"); o.put("v", v) }
            is Int -> { o.put("t", "i"); o.put("v", v) }
            is Float -> { o.put("t", "f"); o.put("v", v.toDouble()) }
            is String -> { o.put("t", "s"); o.put("v", v) }
            is Set<*> -> { o.put("t", "set"); o.put("v", JSONArray(v.map { it.toString() })) }
            else -> continue
        }
        root.put(k, o)
    }
    return root.toString()
}

fun importPrefs(context: Context, json: String): Boolean = try {
    val root = JSONObject(json)
    val ed = context.launcherPrefs().edit()
    val keys = root.keys()
    while (keys.hasNext()) {
        val k = keys.next()
        if (k in BACKUP_EXCLUDED) continue
        val o = root.getJSONObject(k)
        when (o.getString("t")) {
            "b" -> ed.putBoolean(k, o.getBoolean("v"))
            "i" -> ed.putInt(k, o.getInt("v"))
            "f" -> ed.putFloat(k, o.getDouble("v").toFloat())
            "s" -> {
                val v = o.getString("v")
                ed.putString(k, if (k == "homeItems") homeToJson(parseHome(v).filter { it.type != "widget" }) else v)
            }
            "set" -> {
                val a = o.getJSONArray("v")
                ed.putStringSet(k, (0 until a.length()).map { a.getString(it) }.toSet())
            }
        }
    }
    ed.apply()
    true
} catch (e: Exception) {
    false
}

// ---------------- Inicio (JSON) ----------------

fun parseHome(json: String): List<HomeItem> = try {
    val arr = JSONArray(json)
    (0 until arr.length()).map { i ->
        val o = arr.getJSONObject(i)
        HomeItem(
            id = o.getString("id"),
            page = o.getInt("page"),
            col = o.getInt("col"),
            row = o.getInt("row"),
            spanC = o.getInt("sc"),
            spanR = o.getInt("sr"),
            type = o.getString("type"),
            ref = o.getString("ref")
        )
    }
} catch (e: Exception) {
    emptyList()
}

fun homeToJson(list: List<HomeItem>): String {
    val arr = JSONArray()
    list.forEach {
        arr.put(
            JSONObject()
                .put("id", it.id).put("page", it.page).put("col", it.col).put("row", it.row)
                .put("sc", it.spanC).put("sr", it.spanR).put("type", it.type).put("ref", it.ref)
        )
    }
    return arr.toString()
}

fun parseStringList(json: String): List<String> = try {
    val arr = JSONArray(json)
    (0 until arr.length()).map { arr.getString(it) }
} catch (e: Exception) {
    emptyList()
}

fun stringListToJson(list: List<String>): String = JSONArray(list).toString()
