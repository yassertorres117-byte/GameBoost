package com.yts.cyberhud

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.random.Random

private class Star(val x: Float, val y: Float, val r: Float, val speed: Float)

@Composable
fun WallpaperLayer(s: LauncherSettings) {
    val c1 = Color.hsv(s.wallHue1.coerceIn(0f, 360f), 0.7f, s.wallBrightness.coerceIn(0.02f, 0.8f))
    val c2 = Color.hsv(s.wallHue2.coerceIn(0f, 360f), 0.7f, s.wallBrightness.coerceIn(0.02f, 0.8f))
    val speed = s.animSpeed.coerceIn(0.25f, 4f)

    when (s.wallpaperMode) {
        WallpaperMode.SYSTEM -> {
            // No se dibuja nada: se ve el fondo de pantalla del teléfono (tema Wallpaper)
        }

        WallpaperMode.SOLID -> {
            Box(Modifier.fillMaxSize().background(c1))
        }

        WallpaperMode.GRADIENT -> {
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(c1, c2))))
        }

        WallpaperMode.ANIMATED_GRADIENT -> {
            val transition = rememberInfiniteTransition(label = "wall")
            val shift by transition.animateFloat(
                initialValue = 0f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    animation = tween((10000 / speed).toInt(), easing = LinearEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "shift"
            )
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Brush.verticalGradient(listOf(lerp(c1, c2, shift), lerp(c2, c1, shift))))
            )
        }

        WallpaperMode.STARS -> {
            val stars = remember {
                List(90) {
                    Star(
                        x = Random.nextFloat(),
                        y = Random.nextFloat(),
                        r = Random.nextFloat() * 2f + 0.6f,
                        speed = Random.nextFloat() * 0.8f + 0.2f
                    )
                }
            }
            val transition = rememberInfiniteTransition(label = "stars")
            val t by transition.animateFloat(
                initialValue = 0f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    animation = tween((20000 / speed).toInt(), easing = LinearEasing),
                    repeatMode = RepeatMode.Restart
                ),
                label = "t"
            )
            Canvas(Modifier.fillMaxSize().background(c1)) {
                stars.forEach { st ->
                    val y = ((st.y + t * st.speed) % 1f) * size.height
                    drawCircle(
                        color = Color.White.copy(alpha = 0.55f + 0.4f * st.speed / 1f),
                        radius = st.r,
                        center = Offset(st.x * size.width, y)
                    )
                }
            }
        }

        WallpaperMode.PHOTO -> {
            val ctx = LocalContext.current
            val uriStr = s.photoUri
            val bmp by produceState<ImageBitmap?>(initialValue = null, uriStr) {
                value = if (uriStr.isEmpty()) null else withContext(Dispatchers.IO) { loadBitmap(ctx, uriStr) }
            }
            Box(Modifier.fillMaxSize().background(c1)) {
                bmp?.let { img ->
                    val blurMod = if (s.photoBlur > 0f) Modifier.blur(s.photoBlur.dp) else Modifier
                    Image(
                        bitmap = img,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize().then(blurMod)
                    )
                }
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = s.photoDim.coerceIn(0f, 0.9f))))
            }
        }
    }
}

fun loadBitmap(ctx: Context, uriStr: String): ImageBitmap? = try {
    val uri = Uri.parse(uriStr)
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    var sample = 1
    while (bounds.outWidth / sample > 1600 || bounds.outHeight / sample > 2600) sample *= 2
    val opts = BitmapFactory.Options().apply { inSampleSize = sample }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }?.asImageBitmap()
} catch (e: Exception) {
    null
}
